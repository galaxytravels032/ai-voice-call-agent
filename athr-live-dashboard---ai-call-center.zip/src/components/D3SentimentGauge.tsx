import React, { useEffect, useRef } from "react";
import * as d3 from "d3";

interface D3SentimentGaugeProps {
  sentimentScore: number; // -100 to +100 (or 0 to 100)
  sentiment?: "Positive" | "Neutral" | "Negative";
  width?: number;
  height?: number;
}

export const D3SentimentGauge: React.FC<D3SentimentGaugeProps> = ({
  sentimentScore,
  sentiment = "Neutral",
  width = 220,
  height = 120,
}) => {
  const svgRef = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    // Clear previous SVG content
    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    const outerRadius = Math.min(width, height * 2) / 2 - 10;
    const innerRadius = outerRadius - 16;

    const g = svg
      .append("g")
      .attr("transform", `translate(${width / 2}, ${height - 12})`);

    // Angles for semi-circle (-PI/2 to PI/2)
    const minAngle = -Math.PI / 2;
    const maxAngle = Math.PI / 2;

    // Background track arc generator
    const arcGenerator = d3
      .arc<any>()
      .innerRadius(innerRadius)
      .outerRadius(outerRadius)
      .cornerRadius(4);

    // Define 3 sentiment arcs: Negative (red), Neutral (amber), Positive (emerald)
    const arcData = [
      { label: "Negative", startAngle: -Math.PI / 2, endAngle: -Math.PI / 6, color: "#ef4444" },
      { label: "Neutral", startAngle: -Math.PI / 6, endAngle: Math.PI / 6, color: "#f59e0b" },
      { label: "Positive", startAngle: Math.PI / 6, endAngle: Math.PI / 2, color: "#10b981" },
    ];

    arcData.forEach((d) => {
      g.append("path")
        .attr("d", arcGenerator({ startAngle: d.startAngle, endAngle: d.endAngle }))
        .attr("fill", d.color)
        .attr("opacity", 0.85);
    });

    // Map score (-100 to +100) to angle (-PI/2 to +PI/2)
    const normalizedScore = Math.max(-100, Math.min(100, sentimentScore));
    const scale = d3.scaleLinear().domain([-100, 100]).range([minAngle, maxAngle]);
    const needleAngle = scale(normalizedScore);

    // Needle path calculation
    const needleLen = outerRadius - 8;
    const needleRadius = 5;

    // Pivot Circle
    g.append("circle")
      .attr("r", needleRadius + 2)
      .attr("fill", "#1e293b")
      .attr("stroke", "#64748b")
      .attr("stroke-width", 2);

    // Animated Needle
    const needleG = g.append("g").attr("class", "needle-group");

    needleG
      .append("line")
      .attr("x1", 0)
      .attr("y1", 0)
      .attr("x2", 0)
      .attr("y2", -needleLen)
      .attr("stroke", "#f8fafc")
      .attr("stroke-width", 2.5)
      .attr("stroke-linecap", "round");

    needleG
      .append("circle")
      .attr("r", needleRadius)
      .attr("fill", "#6366f1");

    // D3 Transition to animate needle position smooth shift
    needleG
      .attr("transform", "rotate(-90)")
      .transition()
      .duration(800)
      .ease(d3.easeCubicOut)
      .attr("transform", `rotate(${(needleAngle * 180) / Math.PI})`);

    // Add Score Text underneath
    g.append("text")
      .attr("y", -innerRadius / 2.5)
      .attr("text-anchor", "middle")
      .attr("fill", normalizedScore > 20 ? "#10b981" : normalizedScore < -20 ? "#ef4444" : "#f59e0b")
      .attr("font-size", "14px")
      .attr("font-weight", "800")
      .attr("font-family", "monospace")
      .text(`${normalizedScore > 0 ? "+" : ""}${Math.round(normalizedScore)}`);

  }, [sentimentScore, sentiment, width, height]);

  return (
    <div className="flex flex-col items-center justify-center p-2 bg-[#0f131d] border border-slate-800 rounded-xl">
      <div className="flex items-center justify-between w-full text-[10px] uppercase font-mono tracking-wider text-slate-400 px-1 mb-1">
        <span>Tone Shift Gauge</span>
        <span
          className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
            sentiment === "Positive"
              ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
              : sentiment === "Negative"
              ? "bg-rose-500/20 text-rose-400 border border-rose-500/30"
              : "bg-amber-500/20 text-amber-400 border border-amber-500/30"
          }`}
        >
          {sentiment} Tone
        </span>
      </div>
      <svg ref={svgRef} width={width} height={height} className="overflow-visible" />
    </div>
  );
};
