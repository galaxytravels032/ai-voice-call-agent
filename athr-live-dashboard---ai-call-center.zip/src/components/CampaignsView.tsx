import React, { useState, useEffect } from "react";
import { Target, Plus, Play, Pause, TrendingUp, Users, PhoneCall, CheckCircle2, Zap, Radio, RefreshCw } from "lucide-react";
import { Campaign, AgentStatus } from "../types";

interface CampaignsViewProps {
  campaigns: Campaign[];
  agents?: AgentStatus[];
  onAddCampaign?: (camp: Campaign) => void;
  onTriggerCallSimulation?: (customerName?: string, phone?: string) => void;
}

export const CampaignsView: React.FC<CampaignsViewProps> = ({
  campaigns,
  agents = [],
  onTriggerCallSimulation
}) => {
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>("All");
  const [isPredictiveActive, setIsPredictiveActive] = useState<boolean>(true);
  const [dialerLogs, setDialerLogs] = useState<Array<{ id: string; time: string; text: string; status: "success" | "info" }>>([
    { id: "log-1", time: "Just now", text: "Predictive engine monitoring agent availability pool (2 Available)", status: "info" }
  ]);

  const availableAgents = agents.filter((a) => a.status === "AVAILABLE");

  // Predictive Dialer loop: automatically triggers call simulation when agents are available
  useEffect(() => {
    if (!isPredictiveActive || availableAgents.length === 0) return;

    const interval = setInterval(() => {
      const randomNames = ["Enterprise Prospect Inc", "Acme Logistics", "Quantum Solutions", "Cyberdyne Systems", "Apex Global"];
      const randomName = randomNames[Math.floor(Math.random() * randomNames.length)];
      const randomPhone = `+1 (${Math.floor(Math.random() * 800 + 100)}) 555-${Math.floor(Math.random() * 8999 + 1000)}`;

      if (onTriggerCallSimulation) {
        onTriggerCallSimulation(randomName, randomPhone);
        setDialerLogs((prev) => [
          {
            id: `log-${Date.now()}`,
            time: new Date().toLocaleTimeString(),
            text: `Predictive Auto-Dialed ${randomName} (${randomPhone}) -> Connected to ${availableAgents[0]?.name || "AI Agent"}`,
            status: "success"
          },
          ...prev.slice(0, 7)
        ]);
      }
    }, 12000);

    return () => clearInterval(interval);
  }, [isPredictiveActive, availableAgents, onTriggerCallSimulation]);

  const handleManualPredictiveTrigger = () => {
    const randomName = "Priority Lead #" + Math.floor(Math.random() * 899 + 100);
    const randomPhone = `+1 (888) 555-${Math.floor(Math.random() * 8999 + 1000)}`;
    if (onTriggerCallSimulation) {
      onTriggerCallSimulation(randomName, randomPhone);
      setDialerLogs((prev) => [
        {
          id: `log-${Date.now()}`,
          time: new Date().toLocaleTimeString(),
          text: `Manual Predictive Trigger: Dialing ${randomName} (${randomPhone})`,
          status: "success"
        },
        ...prev.slice(0, 7)
      ]);
    }
  };

  const filtered = campaigns.filter((c) =>
    selectedStatusFilter === "All" ? true : c.status === selectedStatusFilter
  );

  return (
    <div className="flex-1 overflow-y-auto bg-[#0b0e14] p-6 space-y-6 text-slate-200 font-sans">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Target className="w-5 h-5 text-blue-400" />
            <span>Outbound & Inbound Campaigns</span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Predictive dialing, target conversion rates, and automated lead allocation
          </p>
        </div>

        <button className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs px-3.5 py-2 rounded-lg flex items-center gap-1.5 transition-colors shadow-md shadow-indigo-950/40 self-start sm:self-auto">
          <Plus className="w-4 h-4" />
          <span>New Campaign</span>
        </button>
      </div>

      {/* Predictive Dialer Engine Control Bar */}
      <div className="bg-[#121620] border border-indigo-500/30 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-lg shadow-indigo-950/20">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shrink-0">
            <Zap className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-white">AI Predictive Dialer Engine</h2>
              <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full font-mono border ${
                isPredictiveActive
                  ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/40"
                  : "bg-slate-800 text-slate-400 border-slate-700"
              }`}>
                {isPredictiveActive ? "ENGINE ACTIVE" : "PAUSED"}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Auto-dials leads based on agent availability algorithm ({availableAgents.length} available agents)
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <button
            onClick={() => setIsPredictiveActive(!isPredictiveActive)}
            className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition-all ${
              isPredictiveActive
                ? "bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-950/40"
                : "bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700"
            }`}
          >
            {isPredictiveActive ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isPredictiveActive ? "Pause Dialer" : "Enable Predictive Dialer"}</span>
          </button>

          <button
            onClick={handleManualPredictiveTrigger}
            className="bg-[#1a1f2c] hover:bg-slate-800 border border-slate-700 text-slate-200 px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5 text-indigo-400" />
            <span>Simulate Outbound Dial</span>
          </button>
        </div>
      </div>

      {/* Live Dialer Activity Stream */}
      <div className="bg-[#121620] border border-slate-800 rounded-xl p-4 space-y-2">
        <div className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
          <Radio className="w-3.5 h-3.5 text-emerald-400" />
          <span>Predictive Engine Live Telephony Logs</span>
        </div>
        <div className="space-y-1.5 max-h-32 overflow-y-auto font-mono text-xs">
          {dialerLogs.map((log) => (
            <div key={log.id} className="p-2 rounded bg-slate-900/80 border border-slate-800/80 flex items-center justify-between">
              <span className="text-slate-300">{log.text}</span>
              <span className="text-[10px] text-slate-500">{log.time}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 text-xs">
        {["All", "Active", "Paused", "Completed"].map((status) => (
          <button
            key={status}
            onClick={() => setSelectedStatusFilter(status)}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
              selectedStatusFilter === status
                ? "bg-slate-800 text-white font-bold border border-slate-700"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40"
            }`}
          >
            {status}
          </button>
        ))}
      </div>

      {/* Campaigns Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((campaign) => (
          <div
            key={campaign.id}
            className="bg-[#121620] border border-slate-800 rounded-xl p-5 space-y-4 shadow-sm hover:border-slate-700 transition-all"
          >
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-white">{campaign.name}</h3>
                <div className="text-[11px] text-slate-400 mt-0.5">{campaign.type}</div>
              </div>
              <span
                className={`px-2 py-0.5 text-[10px] font-bold rounded-full border ${
                  campaign.status === "Active"
                    ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                    : "bg-amber-500/20 text-amber-400 border-amber-500/30"
                }`}
              >
                {campaign.status}
              </span>
            </div>

            {/* Progress Bar */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-slate-400">Completion</span>
                <span className="text-white font-bold">{campaign.completionPercentage}%</span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                <div
                  style={{ width: `${campaign.completionPercentage}%` }}
                  className="bg-indigo-500 h-full rounded-full transition-all"
                />
              </div>
            </div>

            {/* Stats Breakdown */}
            <div className="grid grid-cols-3 gap-2 bg-slate-900/80 p-2.5 rounded-lg text-center border border-slate-800 font-mono">
              <div>
                <div className="text-[10px] text-slate-500">Total Leads</div>
                <div className="text-xs font-bold text-white mt-0.5">{campaign.totalLeads}</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-500">Dialed</div>
                <div className="text-xs font-bold text-indigo-400 mt-0.5">{campaign.dialedCount}</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-500">Converted</div>
                <div className="text-xs font-bold text-emerald-400 mt-0.5">{campaign.convertedCount}</div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 text-xs border-t border-slate-800">
              <span className="text-slate-500">Agents: {campaign.assignedAgentIds.length} assigned</span>
              <button
                onClick={handleManualPredictiveTrigger}
                className="text-indigo-400 hover:text-indigo-300 font-medium"
              >
                Trigger Predictive Dial →
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
