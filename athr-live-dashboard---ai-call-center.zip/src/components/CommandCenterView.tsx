import React, { useState, useEffect } from "react";
import {
  Radio,
  Phone,
  Mic,
  Eye,
  MessageSquare,
  ShieldAlert,
  Play,
  Volume2,
  VolumeX,
  Users,
  Sparkles,
  Zap,
  PhoneOff,
  PhoneForwarded,
  X,
  Music,
  CheckCircle2
} from "lucide-react";
import { ActiveCall, AgentStatus } from "../types";
import {
  playDtmfTone,
  playCallConnectChime,
  playCallEndChime,
  playVerificationPing,
  playTransferTone,
  startHoldMusic,
  stopHoldMusic
} from "../utils/audioSynth";

interface CommandCenterViewProps {
  activeCalls: ActiveCall[];
  agents: AgentStatus[];
  onOpenSimulator: () => void;
  onEndCall?: (callId: string) => void;
  onMuteCall?: (callId: string) => void;
}

export const CommandCenterView: React.FC<CommandCenterViewProps> = ({
  activeCalls,
  agents,
  onOpenSimulator,
  onEndCall,
  onMuteCall,
}) => {
  const [dialedNumber, setDialedNumber] = useState("");
  const [selectedAgentWhisper, setSelectedAgentWhisper] = useState<string | null>(null);
  const [selectedCallIds, setSelectedCallIds] = useState<string[]>([]);
  const [isPlayingHoldMusic, setIsPlayingHoldMusic] = useState(false);

  useEffect(() => {
    setSelectedCallIds((prev) => prev.filter((id) => activeCalls.some((c) => c.id === id)));
  }, [activeCalls]);

  const handleDigit = (digit: string) => {
    playDtmfTone(digit);
    setDialedNumber((prev) => prev + digit);
  };

  const handleToggleHoldMusic = () => {
    if (isPlayingHoldMusic) {
      stopHoldMusic();
      setIsPlayingHoldMusic(false);
    } else {
      startHoldMusic();
      setIsPlayingHoldMusic(true);
    }
  };

  const handleToggleSelectAll = () => {
    if (selectedCallIds.length === activeCalls.length) {
      setSelectedCallIds([]);
    } else {
      setSelectedCallIds(activeCalls.map((c) => c.id));
    }
  };

  const handleToggleSelect = (id: string) => {
    setSelectedCallIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleBulkEnd = () => {
    if (selectedCallIds.length === 0) return;
    playCallEndChime();
    if (onEndCall) {
      selectedCallIds.forEach((id) => onEndCall(id));
    }
    setSelectedCallIds([]);
  };

  const handleBulkMute = () => {
    if (selectedCallIds.length === 0) return;
    if (onMuteCall) {
      selectedCallIds.forEach((id) => onMuteCall(id));
    }
  };

  return (
    <div className="flex-1 overflow-y-auto bg-[#0b0e14] p-6 space-y-6 text-slate-200 font-sans">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Radio className="w-5 h-5 text-amber-400" />
            <span>Telephony Command Center</span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time supervisor dispatch, whisper mode, and agent barge-in workspace
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenSimulator}
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Quick Outbound Dispatch</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Dialpad & Quick Dispatcher & Soundboard */}
        <div className="space-y-6">
          <div className="bg-[#121620] border border-slate-800 rounded-xl p-5 space-y-4">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Phone className="w-4 h-4 text-indigo-400" />
              <span>Supervisor Manual Dialpad</span>
            </h2>

            <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg text-right font-mono text-lg text-emerald-400 tracking-wider min-h-[44px] flex items-center justify-end">
              {dialedNumber || "Enter number..."}
            </div>

            <div className="grid grid-cols-3 gap-2">
              {["1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#"].map((d) => (
                <button
                  key={d}
                  onClick={() => handleDigit(d)}
                  className="bg-[#1a1f2c] hover:bg-slate-800 text-white font-bold py-3 rounded-lg border border-slate-800/80 transition-colors active:scale-95 text-sm"
                >
                  {d}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => setDialedNumber("")}
                className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 py-2 rounded-lg text-xs font-semibold"
              >
                Clear
              </button>
              <button
                onClick={onOpenSimulator}
                className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white py-2 rounded-lg text-xs font-bold"
              >
                Call Out
              </button>
            </div>
          </div>

          {/* Audio Soundboard FX Widget */}
          <div className="bg-[#121620] border border-slate-800 rounded-xl p-5 space-y-3">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Music className="w-4 h-4 text-purple-400" />
              <span>Telephony Audio FX Soundboard</span>
            </h2>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={playCallConnectChime}
                className="p-2.5 bg-[#181d2a] hover:bg-slate-800 border border-slate-800 rounded-lg text-slate-200 font-medium flex items-center gap-2 transition-all active:scale-95"
              >
                <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Connect Chime</span>
              </button>

              <button
                onClick={playVerificationPing}
                className="p-2.5 bg-[#181d2a] hover:bg-slate-800 border border-slate-800 rounded-lg text-slate-200 font-medium flex items-center gap-2 transition-all active:scale-95"
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-sky-400" />
                <span>Verify Ping</span>
              </button>

              <button
                onClick={playTransferTone}
                className="p-2.5 bg-[#181d2a] hover:bg-slate-800 border border-slate-800 rounded-lg text-slate-200 font-medium flex items-center gap-2 transition-all active:scale-95"
              >
                <PhoneForwarded className="w-3.5 h-3.5 text-amber-400" />
                <span>Transfer Tone</span>
              </button>

              <button
                onClick={playCallEndChime}
                className="p-2.5 bg-[#181d2a] hover:bg-slate-800 border border-slate-800 rounded-lg text-slate-200 font-medium flex items-center gap-2 transition-all active:scale-95"
              >
                <PhoneOff className="w-3.5 h-3.5 text-rose-400" />
                <span>Hangup Chime</span>
              </button>
            </div>

            <button
              onClick={handleToggleHoldMusic}
              className={`w-full py-2.5 px-3 rounded-lg border text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
                isPlayingHoldMusic
                  ? "bg-purple-500/20 text-purple-300 border-purple-500/50 animate-pulse"
                  : "bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700"
              }`}
            >
              <Music className="w-3.5 h-3.5" />
              <span>{isPlayingHoldMusic ? "Stop Hold Synth Music" : "Play Hold Synth Music Loop"}</span>
            </button>
          </div>
        </div>

        {/* Live Active Channels */}
        <div className="lg:col-span-2 bg-[#121620] border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2.5">
              <input
                type="checkbox"
                checked={activeCalls.length > 0 && selectedCallIds.length === activeCalls.length}
                onChange={handleToggleSelectAll}
                disabled={activeCalls.length === 0}
                className="w-4 h-4 rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-indigo-500 cursor-pointer disabled:opacity-40"
                title="Select all streams"
              />
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-emerald-400" />
                <span>Supervisor Monitor Matrix</span>
              </h2>
            </div>
            <div className="flex items-center gap-2">
              {selectedCallIds.length > 0 && (
                <span className="text-xs px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-bold border border-indigo-500/30">
                  {selectedCallIds.length} Selected
                </span>
              )}
              <span className="text-xs text-slate-400 font-mono">
                {activeCalls.length} Active Streams
              </span>
            </div>
          </div>

          {activeCalls.length === 0 ? (
            <div className="py-12 text-center text-slate-500 space-y-2">
              <Mic className="w-8 h-8 mx-auto text-slate-600" />
              <div className="text-xs font-semibold">No active channels currently being monitored</div>
              <p className="text-[11px] max-w-sm mx-auto">
                When agents connect to callers, their real-time audio channels will display here with whisper and barge-in controls.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {activeCalls.map((call) => {
                const isSelected = selectedCallIds.includes(call.id);
                return (
                  <div
                    key={call.id}
                    className={`p-4 bg-[#181d2a] border rounded-xl space-y-3 transition-all ${
                      isSelected
                        ? "border-indigo-500 ring-1 ring-indigo-500/50 bg-indigo-950/20"
                        : "border-slate-800"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => handleToggleSelect(call.id)}
                          className="w-4 h-4 rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                        />
                        <div>
                          <div className="text-xs font-bold text-white flex items-center gap-2">
                            <span>{call.customerName}</span>
                            <span className="text-[10px] text-emerald-400 font-mono font-semibold">
                              ({call.phoneNumber})
                            </span>
                            {call.status === "muted" && (
                              <span className="text-[9px] bg-amber-500/20 text-amber-400 px-1 py-0.2 rounded border border-amber-500/30">
                                MUTED
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-slate-400 mt-0.5">
                            Assigned: {call.agentName}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 text-xs">
                        <button
                          onClick={() => setSelectedAgentWhisper(call.agentName)}
                          className="bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300 border border-indigo-500/40 px-2.5 py-1 rounded-md flex items-center gap-1 font-medium"
                        >
                          <Eye className="w-3 h-3" />
                          <span>Whisper Mode</span>
                        </button>
                        <button className="bg-rose-600/30 hover:bg-rose-600/50 text-rose-300 border border-rose-500/40 px-2.5 py-1 rounded-md flex items-center gap-1 font-medium">
                          <ShieldAlert className="w-3 h-3" />
                          <span>Barge-In</span>
                        </button>
                      </div>
                    </div>

                    <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800 text-xs text-slate-300">
                      <span className="text-slate-500 font-semibold">Live AI Copilot Note:</span>{" "}
                      Customer sentiment is {call.sentiment} ({call.sentimentScore}). Agent recommended to confirm billing details.
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Supervisor Live Whisper / Barge-In Directive Modal */}
      {selectedAgentWhisper && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#121620] border border-indigo-500/50 rounded-2xl p-6 max-w-md w-full space-y-4 shadow-2xl shadow-indigo-950">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-lg bg-indigo-500/20 text-indigo-400">
                  <Eye className="w-4 h-4" />
                </span>
                <div>
                  <h3 className="text-sm font-bold text-white">Supervisor Whisper Injection</h3>
                  <div className="text-[11px] text-slate-400 font-mono">Target: {selectedAgentWhisper}</div>
                </div>
              </div>
              <button
                onClick={() => setSelectedAgentWhisper(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-300">
              Inject a real-time prompt into the agent's earpiece without the customer hearing. The Gemini AI agent copilot will process this directive immediately.
            </p>

            <div className="space-y-2">
              <label className="text-[11px] font-semibold text-slate-400">Quick Directive Options:</label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  onClick={() => {
                    playVerificationPing();
                    alert(`Whisper sent to ${selectedAgentWhisper}: "Offer 15% discount code ATHR15"`);
                    setSelectedAgentWhisper(null);
                  }}
                  className="p-2 bg-[#181d2a] hover:bg-indigo-900/40 border border-slate-700 hover:border-indigo-500 rounded-lg text-slate-200 text-left transition-colors font-medium"
                >
                  "Offer 15% Promo"
                </button>
                <button
                  onClick={() => {
                    playTransferTone();
                    alert(`Whisper sent to ${selectedAgentWhisper}: "Initiate warm transfer to Tier 2 Support"`);
                    setSelectedAgentWhisper(null);
                  }}
                  className="p-2 bg-[#181d2a] hover:bg-indigo-900/40 border border-slate-700 hover:border-indigo-500 rounded-lg text-slate-200 text-left transition-colors font-medium"
                >
                  "Transfer to Tier 2"
                </button>
                <button
                  onClick={() => {
                    playVerificationPing();
                    alert(`Whisper sent to ${selectedAgentWhisper}: "Verify security PIN before proceeding"`);
                    setSelectedAgentWhisper(null);
                  }}
                  className="p-2 bg-[#181d2a] hover:bg-indigo-900/40 border border-slate-700 hover:border-indigo-500 rounded-lg text-slate-200 text-left transition-colors font-medium"
                >
                  "Verify Security PIN"
                </button>
                <button
                  onClick={() => {
                    playVerificationPing();
                    alert(`Whisper sent to ${selectedAgentWhisper}: "Ask for feedback on service quality"`);
                    setSelectedAgentWhisper(null);
                  }}
                  className="p-2 bg-[#181d2a] hover:bg-indigo-900/40 border border-slate-700 hover:border-indigo-500 rounded-lg text-slate-200 text-left transition-colors font-medium"
                >
                  "Request Feedback"
                </button>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setSelectedAgentWhisper(null)}
                className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Action Bar */}
      {selectedCallIds.length > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-[#161b26] border border-indigo-500/50 shadow-2xl shadow-indigo-950/80 rounded-2xl px-5 py-3.5 flex items-center gap-4 text-white backdrop-blur-md animate-fadeIn transition-all">
          <div className="flex items-center gap-2.5">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-indigo-500"></span>
            </span>
            <div className="text-xs font-bold text-slate-100 font-mono">
              {selectedCallIds.length} Stream{selectedCallIds.length > 1 ? "s" : ""} Selected
            </div>
          </div>

          <div className="h-5 w-px bg-slate-700/80" />

          <div className="flex items-center gap-2">
            <button
              onClick={handleBulkMute}
              className="bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 transition-all active:scale-95"
            >
              <VolumeX className="w-3.5 h-3.5" />
              <span>Bulk Mute</span>
            </button>

            <button
              onClick={handleBulkEnd}
              className="bg-rose-600 hover:bg-rose-500 text-white text-xs px-3.5 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition-all shadow-md shadow-rose-950/50 active:scale-95"
            >
              <PhoneOff className="w-3.5 h-3.5" />
              <span>Bulk End ({selectedCallIds.length})</span>
            </button>
          </div>

          <div className="h-5 w-px bg-slate-700/80" />

          <button
            onClick={() => setSelectedCallIds([])}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
};
