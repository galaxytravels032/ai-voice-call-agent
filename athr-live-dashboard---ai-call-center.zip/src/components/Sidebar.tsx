import React from "react";
import {
  LayoutDashboard,
  Radio,
  Target,
  ListOrdered,
  FileText,
  Bot,
  Mail,
  Wrench,
  SlidersHorizontal,
  History,
  Mic,
  BarChart3,
  FileSpreadsheet,
  CreditCard,
  Settings,
  Sparkles,
  ChevronRight,
  UserCheck,
  Server
} from "lucide-react";
import { NavSection } from "../types";

interface SidebarProps {
  currentSection: NavSection;
  onSelectSection: (section: NavSection) => void;
  activeCallsCount: number;
  queuedCallsCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentSection,
  onSelectSection,
  activeCallsCount,
  queuedCallsCount,
}) => {
  const navItems: {
    group: string;
    items: {
      id: NavSection;
      label: string;
      icon: React.ElementType;
      badge?: string | number;
      badgeColor?: string;
    }[];
  }[] = [
    {
      group: "OVERVIEW",
      items: [
        {
          id: "dashboard",
          label: "Dashboard",
          icon: LayoutDashboard,
          badge: 243,
          badgeColor: "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30",
        },
      ],
    },
    {
      group: "CALL CENTER",
      items: [
        {
          id: "command_center",
          label: "Command Center",
          icon: Radio,
          badge: queuedCallsCount + activeCallsCount || 12,
          badgeColor: "bg-amber-500/20 text-amber-400 border border-amber-500/30",
        },
        {
          id: "asterisk_gateway",
          label: "Asterisk PBX",
          icon: Server,
          badge: "PJSIP",
          badgeColor: "bg-indigo-500/20 text-indigo-300 border border-indigo-500/30",
        },
        {
          id: "campaigns",
          label: "Campaigns",
          icon: Target,
          badge: "87%",
          badgeColor: "bg-blue-500/20 text-blue-400 border border-blue-500/30",
        },
        { id: "phone_lists", label: "Phone Lists", icon: ListOrdered },
        { id: "scripts", label: "Scripts", icon: FileText },
        { id: "ai_agent_scripts", label: "AI Agent Scripts", icon: Bot },
        {
          id: "email_sender",
          label: "Email Sender",
          icon: Mail,
          badge: "AI",
          badgeColor: "bg-purple-500/20 text-purple-400 border border-purple-500/30",
        },
      ],
    },
    {
      group: "TOOLS",
      items: [
        { id: "all_tools", label: "All Tools", icon: Wrench },
        { id: "panel", label: "Panel", icon: SlidersHorizontal },
      ],
    },
    {
      group: "CONTENT",
      items: [
        { id: "call_records", label: "Call Records", icon: History },
        { id: "call_recordings", label: "Call Recordings", icon: Mic },
      ],
    },
    {
      group: "ANALYTICS",
      items: [
        { id: "analytics", label: "Analytics", icon: BarChart3 },
        { id: "reports", label: "Reports", icon: FileSpreadsheet },
      ],
    },
    {
      group: "SYSTEM",
      items: [
        { id: "billing", label: "Billing", icon: CreditCard },
        { id: "settings", label: "Settings", icon: Settings },
        { id: "changelog", label: "Changelog", icon: Sparkles },
      ],
    },
  ];

  return (
    <aside className="w-64 bg-[#0a0c10] border-r border-slate-800/80 flex flex-col h-screen select-none shrink-0 text-slate-300 font-sans">
      {/* Brand Profile Header */}
      <div className="p-4 border-b border-slate-800/80 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm shadow-md shadow-indigo-500/20">
            D
          </div>
          <div>
            <div className="text-sm font-semibold text-slate-100 flex items-center gap-1.5">
              <span>Domii</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            </div>
            <div className="text-xs text-slate-500 font-medium">Administrator</div>
          </div>
        </div>
        <button className="text-slate-500 hover:text-slate-300 transition-colors p-1 rounded-md hover:bg-slate-800/50">
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Navigation Scrollable Body */}
      <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6 scrollbar-thin scrollbar-thumb-slate-800">
        {navItems.map((group) => (
          <div key={group.group} className="space-y-1">
            <div className="px-2 text-[10px] font-bold tracking-wider text-slate-500 uppercase">
              {group.group}
            </div>
            <div className="mt-1 space-y-0.5">
              {group.items.map((item) => {
                const Icon = item.icon;
                const isActive = currentSection === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onSelectSection(item.id)}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md text-xs font-medium transition-all ${
                      isActive
                        ? "bg-slate-800/90 text-white font-semibold border-l-2 border-indigo-500 shadow-sm"
                        : "text-slate-400 hover:bg-slate-800/40 hover:text-slate-200"
                    }`}
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      <Icon className={`w-4 h-4 shrink-0 ${isActive ? "text-indigo-400" : "text-slate-500"}`} />
                      <span className="truncate">{item.label}</span>
                    </div>
                    {item.badge !== undefined && (
                      <span
                        className={`px-1.5 py-0.5 text-[10px] rounded font-semibold ${
                          item.badgeColor || "bg-slate-800 text-slate-400"
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Agent Voice Status Footer */}
      <div className="p-3 border-t border-slate-800/80 bg-[#07090d]">
        <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-2.5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 ring-4 ring-emerald-500/20 animate-pulse"></div>
            <div>
              <div className="text-xs font-medium text-slate-200">ATHR Voice Node</div>
              <div className="text-[10px] text-emerald-400 font-mono">Gemini 3.6 Connected</div>
            </div>
          </div>
          <UserCheck className="w-4 h-4 text-slate-500" />
        </div>
      </div>
    </aside>
  );
};
