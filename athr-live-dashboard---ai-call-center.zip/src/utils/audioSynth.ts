// Web Audio API Synthesizer for Telephony sound effects (DTMF tones, ringback, call chimes, hold music)

let audioCtx: AudioContext | null = null;
let holdOsc1: OscillatorNode | null = null;
let holdOsc2: OscillatorNode | null = null;
let holdGain: GainNode | null = null;

function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    audioCtx = new AudioContextClass();
  }
  if (audioCtx.state === "suspended") {
    audioCtx.resume();
  }
  return audioCtx;
}

// DTMF Frequencies (Hz) for Phone Keypad
const DTMF_FREQS: Record<string, [number, number]> = {
  "1": [697, 1209],
  "2": [697, 1336],
  "3": [697, 1477],
  "4": [770, 1209],
  "5": [770, 1336],
  "6": [770, 1477],
  "7": [852, 1209],
  "8": [852, 1336],
  "9": [852, 1477],
  "*": [941, 1209],
  "0": [941, 1336],
  "#": [941, 1477],
};

/**
 * Play standard dual-tone multi-frequency (DTMF) keypad tone
 */
export function playDtmfTone(digit: string, durationMs = 120) {
  try {
    const ctx = getAudioContext();
    const freqs = DTMF_FREQS[digit];
    if (!freqs) return;

    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gainNode = ctx.createGain();

    osc1.frequency.value = freqs[0];
    osc2.frequency.value = freqs[1];

    gainNode.gain.setValueAtTime(0.1, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + durationMs / 1000);

    osc1.connect(gainNode);
    osc2.connect(gainNode);
    gainNode.connect(ctx.destination);

    osc1.start();
    osc2.start();
    osc1.stop(ctx.currentTime + durationMs / 1000);
    osc2.stop(ctx.currentTime + durationMs / 1000);
  } catch (e) {
    console.warn("Audio Context playback ignored:", e);
  }
}

/**
 * Play phone connect chime
 */
export function playCallConnectChime() {
  try {
    const ctx = getAudioContext();
    const osc = ctx.createOscillator();
    const gainNode = ctx.createGain();

    osc.type = "sine";
    osc.frequency.setValueAtTime(440, ctx.currentTime); // A4
    osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.15); // A5

    gainNode.gain.setValueAtTime(0.12, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);

    osc.connect(gainNode);
    gainNode.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 0.3);
  } catch (e) {
    console.warn(e);
  }
}

/**
 * Play phone end/hangup chime
 */
export function playCallEndChime() {
  try {
    const ctx = getAudioContext();
    const osc = ctx.createOscillator();
    const gainNode = ctx.createGain();

    osc.type = "sine";
    osc.frequency.setValueAtTime(600, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(220, ctx.currentTime + 0.2);

    gainNode.gain.setValueAtTime(0.12, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);

    osc.connect(gainNode);
    gainNode.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 0.25);
  } catch (e) {
    console.warn(e);
  }
}

/**
 * Play Verification Success Ping Tone
 */
export function playVerificationPing() {
  try {
    const ctx = getAudioContext();
    const osc = ctx.createOscillator();
    const gainNode = ctx.createGain();

    osc.type = "sine";
    osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
    osc.frequency.setValueAtTime(659.25, ctx.currentTime + 0.1); // E5
    osc.frequency.setValueAtTime(783.99, ctx.currentTime + 0.2); // G5

    gainNode.gain.setValueAtTime(0.1, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);

    osc.connect(gainNode);
    gainNode.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 0.4);
  } catch (e) {
    console.warn(e);
  }
}

/**
 * Play Call Transfer Intercom Tone
 */
export function playTransferTone() {
  try {
    const ctx = getAudioContext();
    const osc = ctx.createOscillator();
    const gainNode = ctx.createGain();

    osc.type = "triangle";
    osc.frequency.setValueAtTime(350, ctx.currentTime);
    osc.frequency.setValueAtTime(440, ctx.currentTime + 0.12);

    gainNode.gain.setValueAtTime(0.1, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);

    osc.connect(gainNode);
    gainNode.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 0.35);
  } catch (e) {
    console.warn(e);
  }
}

/**
 * Start ambient synthesizer hold music loop
 */
export function startHoldMusic() {
  stopHoldMusic();
  try {
    const ctx = getAudioContext();
    holdOsc1 = ctx.createOscillator();
    holdOsc2 = ctx.createOscillator();
    holdGain = ctx.createGain();

    holdOsc1.type = "sine";
    holdOsc2.type = "triangle";

    holdOsc1.frequency.value = 220; // A3
    holdOsc2.frequency.value = 329.63; // E4

    holdGain.gain.setValueAtTime(0.05, ctx.currentTime);

    holdOsc1.connect(holdGain);
    holdOsc2.connect(holdGain);
    holdGain.connect(ctx.destination);

    holdOsc1.start();
    holdOsc2.start();
  } catch (e) {
    console.warn(e);
  }
}

/**
 * Stop ambient hold music loop
 */
export function stopHoldMusic() {
  try {
    if (holdOsc1) {
      holdOsc1.stop();
      holdOsc1.disconnect();
      holdOsc1 = null;
    }
    if (holdOsc2) {
      holdOsc2.stop();
      holdOsc2.disconnect();
      holdOsc2 = null;
    }
  } catch (e) {
    console.warn(e);
  }
}

