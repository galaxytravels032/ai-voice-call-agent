import React, { useState } from "react";
import { Search, Bell, Sun, PhoneCall, Sparkles, X } from "lucide-react";

interface HeaderProps {
  onOpenSimulator: () => void;
  onSearchQuery?: (q: string) => void;
  isLiveSimActive?: boolean;
  onToggleLiveSim?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenSimulator,
  onSearchQuery,
  isLiveSimActive = true,
  onToggleLiveSim,
}) => {
  const [searchVal, setSearchVal] = useState("");
  const [notificationsOpen, setNotificationsOpen] = useState(false);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchVal(e.target.value);
    if (onSearchQuery) onSearchQuery(e.target.value);
  };

  return (
    <header className="h-14 bg-[#0a0c10] border-b border-slate-800/80 px-6 flex items-center justify-between shrink-0 text-slate-300">
      {/* Search Input matching Cmd+K badge in screenshot */}
      <div className="relative w-72">
        <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
        <input
          type="text"
          value={searchVal}
          onChange={handleSearchChange}
          placeholder="Search"
          className="w-full bg-[#12161f] border border-slate-800 text-slate-200 text-xs rounded-md pl-9 pr-14 py-1.5 focus:outline-none focus:border-indigo-500/60 focus:ring-1 focus:ring-indigo-500/40 transition-all placeholder:text-slate-600 font-medium"
        />
        <div className="absolute right-2 top-1/2 -translate-y-1/2 px-1.5 py-0.5 bg-slate-800 border border-slate-700/60 text-[10px] text-slate-400 font-mono rounded">
          Cmd+K
        </div>
      </div>

      {/* Right Action Tools */}
      <div className="flex items-center gap-3">
        {/* Live Simulation Status Indicator Button */}
        {onToggleLiveSim && (
          <button
            onClick={onToggleLiveSim}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md border text-[11px] font-bold tracking-wider uppercase transition-all ${
              isLiveSimActive
                ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/40 hover:bg-emerald-500/20 shadow-sm shadow-emerald-950/50"
                : "bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200"
            }`}
            title="Click to toggle real-time background call traffic simulation"
          >
            <span className="relative flex h-2 w-2">
              {isLiveSimActive && (
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              )}
              <span
                className={`relative inline-flex rounded-full h-2 w-2 ${
                  isLiveSimActive ? "bg-emerald-400" : "bg-slate-500"
                }`}
              ></span>
            </span>
            <span>{isLiveSimActive ? "Live Engine Active" : "Engine Paused"}</span>
          </button>
        )}
        {/* Simulate Call Trigger Button */}
        <button
          onClick={onOpenSimulator}
          className="flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-semibold px-3 py-1.5 rounded-md shadow-md shadow-emerald-950/40 transition-all active:scale-95"
        >
          <PhoneCall className="w-3.5 h-3.5" />
          <span>Simulate Call</span>
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-200 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-100"></span>
          </span>
        </button>

        {/* Notifications Dropdown */}
        <div className="relative">
          <button
            onClick={() => setNotificationsOpen(!notificationsOpen)}
            className="p-2 text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 rounded-md transition-colors relative"
            title="System Alerts"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-amber-500"></span>
          </button>

          {notificationsOpen && (
            <div className="absolute right-0 mt-2 w-80 bg-[#121620] border border-slate-800 rounded-lg shadow-xl py-2 z-50 text-xs text-slate-300">
              <div className="px-3 py-2 border-b border-slate-800 flex items-center justify-between font-semibold text-slate-200">
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  Realtime Telephony Events
                </span>
                <button
                  onClick={() => setNotificationsOpen(false)}
                  className="text-slate-500 hover:text-slate-300"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="max-h-60 overflow-y-auto divide-y divide-slate-800/60">
                <div className="p-3 hover:bg-slate-800/40 transition-colors">
                  <div className="text-emerald-400 font-medium text-[11px]">IVR Key '1' Pressed</div>
                  <div className="text-slate-400 text-[10px] mt-0.5">Caller +1 (555) 382-9102 routed to ATHR AI Queue</div>
                  <div className="text-slate-500 text-[9px] mt-1">2 mins ago</div>
                </div>
                <div className="p-3 hover:bg-slate-800/40 transition-colors">
                  <div className="text-indigo-400 font-medium text-[11px]">Gemini 3.6 Flash Voice Ready</div>
                  <div className="text-slate-400 text-[10px]">Real-time latency verified &lt; 350ms</div>
                  <div className="text-slate-500 text-[9px] mt-1">5 mins ago</div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Theme Sun Toggle */}
        <button
          className="p-2 text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 rounded-md transition-colors"
          title="Theme Toggle"
        >
          <Sun className="w-4 h-4 text-amber-400" />
        </button>
      </div>
    </header>
  );
};
