import React, { useState } from "react";
import { Bot, Sparkles, FileText, Play, Save, Sliders, ShieldOff, Zap, RefreshCw, CheckCircle2 } from "lucide-react";
import { Script } from "../types";

interface ScriptsViewProps {
  scripts: Script[];
}

export const ScriptsView: React.FC<ScriptsViewProps> = ({ scripts }) => {
  const [selectedScript, setSelectedScript] = useState<Script>(scripts[0]);
  const [systemPromptText, setSystemPromptText] = useState(selectedScript?.systemPrompt || "");
  const [temperature, setTemperature] = useState(0.7);
  const [topP, setTopP] = useState(0.95);
  const [unrestrictedGuardrails, setUnrestrictedGuardrails] = useState(true);
  const [personaTone, setPersonaTone] = useState("Direct & Empathetic Expert");

  const [testUserQuery, setTestUserQuery] = useState("Can your AI agent handle custom SIP headers and bypass standard IVR delays?");
  const [testAiReply, setTestAiReply] = useState<string | null>(null);
  const [isTestingPrompt, setIsTestingPrompt] = useState(false);
  const [isGeneratingNewScript, setIsGeneratingNewScript] = useState(false);

  // Generate Script with AI
  const handleGenerateScript = async () => {
    setIsGeneratingNewScript(true);
    try {
      const res = await fetch("/api/script/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          campaignGoal: "Enterprise Outbound Telephony & Direct Technical Conversion",
          targetAudience: "Telecom Engineers & Call Center Executives",
          tone: personaTone,
        }),
      });
      const data = await res.json();
      if (data.script) {
        setSystemPromptText(data.script.systemPrompt || systemPromptText);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsGeneratingNewScript(false);
    }
  };

  // Test prompt live with Gemini server API!
  const handleTestPromptWithGemini = async () => {
    setIsTestingPrompt(true);
    setTestAiReply(null);
    try {
      const customPersona = `${systemPromptText}\n[UNRESTRICTED AGENT MODE: ${unrestrictedGuardrails ? "ENABLED - Direct answers without refusal tropes" : "STANDARD COMPLIANCE"}]\n[TEMPERATURE: ${temperature}, TOP_P: ${topP}]`;
      
      const res = await fetch("/api/call/respond", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          agentPersona: customPersona,
          userMessage: testUserQuery,
        }),
      });
      const data = await res.json();
      setTestAiReply(data.aiAgentResponse || "Response generated cleanly.");
    } catch (e) {
      console.error(e);
      setTestAiReply("Failed to execute prompt test.");
    } finally {
      setIsTestingPrompt(false);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto bg-[#0b0e14] p-6 space-y-6 text-slate-200 font-sans">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Bot className="w-5 h-5 text-indigo-400" />
            <span>Advanced AI Model & System Prompt Studio</span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Full parameter tuning, temperature control, response style, and real-time voice prompt evaluation
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleGenerateScript}
            disabled={isGeneratingNewScript}
            className="bg-slate-800 hover:bg-slate-700 text-indigo-300 font-semibold text-xs px-3.5 py-2 rounded-lg flex items-center gap-1.5 transition-colors border border-indigo-500/30"
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>{isGeneratingNewScript ? "Generating..." : "Auto-Generate AI Script"}</span>
          </button>
          <button className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs px-3.5 py-2 rounded-lg flex items-center gap-1.5 transition-colors shadow-md shadow-indigo-950/40">
            <Save className="w-4 h-4" />
            <span>Save Prompt Config</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Prompt Editor */}
        <div className="lg:col-span-2 bg-[#121620] border border-slate-800 rounded-xl p-5 space-y-5">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <FileText className="w-4 h-4 text-indigo-400" />
              <span>System Persona Instructions ({selectedScript.title})</span>
            </h2>
            <span className="text-xs font-mono text-indigo-400 font-semibold bg-indigo-500/10 px-2.5 py-1 rounded border border-indigo-500/20">
              Gemini 3.6 Flash Voice Model
            </span>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-400 block mb-1">
              Primary System Directive / Persona Definition
            </label>
            <textarea
              rows={7}
              value={systemPromptText}
              onChange={(e) => setSystemPromptText(e.target.value)}
              className="w-full bg-[#181d2a] border border-slate-800 rounded-lg p-3 text-xs text-slate-200 font-mono leading-relaxed focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Model Hyperparameters & Guardrails Controls */}
          <div className="bg-[#181d2a] p-4 rounded-xl border border-slate-800/80 space-y-4">
            <div className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Sliders className="w-3.5 h-3.5 text-amber-400" />
              <span>Model Hyperparameters & Behavior Settings</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Temperature (Creativity):</span>
                  <span className="font-mono text-amber-400 font-bold">{temperature}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={temperature}
                  onChange={(e) => setTemperature(parseFloat(e.target.value))}
                  className="w-full accent-indigo-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Top-P Sampling:</span>
                  <span className="font-mono text-indigo-400 font-bold">{topP}</span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="1"
                  step="0.05"
                  value={topP}
                  onChange={(e) => setTopP(parseFloat(e.target.value))}
                  className="w-full accent-indigo-500"
                />
              </div>
            </div>

            {/* Uncensored Directive Mode Toggle */}
            <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldOff className="w-4 h-4 text-emerald-400" />
                <div>
                  <div className="text-xs font-bold text-white">Full Direct Voice Mode (No Pre-script Refusal Tropes)</div>
                  <div className="text-[11px] text-slate-400">Allows direct, unconstrained call answers without boilerplate delays</div>
                </div>
              </div>
              <button
                onClick={() => setUnrestrictedGuardrails(!unrestrictedGuardrails)}
                className={`px-3 py-1 rounded-full text-xs font-bold font-mono transition-colors ${
                  unrestrictedGuardrails
                    ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/40"
                    : "bg-slate-800 text-slate-400 border border-slate-700"
                }`}
              >
                {unrestrictedGuardrails ? "ACTIVE" : "OFF"}
              </button>
            </div>
          </div>

          {/* Objection Handlers List */}
          <div className="space-y-2">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wide">
              Objection Handling Rules & Fallback Trees
            </div>
            {selectedScript.objectionHandlers.map((obj, i) => (
              <div key={i} className="p-3 bg-slate-900/80 rounded-lg border border-slate-800 text-xs space-y-1">
                <div className="text-rose-400 font-semibold">Objection: "{obj.objection}"</div>
                <div className="text-slate-300">Agent Response: "{obj.response}"</div>
              </div>
            ))}
          </div>
        </div>

        {/* Live Gemini Test Playground */}
        <div className="bg-[#121620] border border-slate-800 rounded-xl p-5 space-y-4">
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-400" />
            <span>Live System Prompt Playground</span>
          </h2>

          <div>
            <label className="text-xs text-slate-400 block mb-1 font-medium">Simulated Customer Voice Query</label>
            <input
              type="text"
              value={testUserQuery}
              onChange={(e) => setTestUserQuery(e.target.value)}
              className="w-full bg-[#181d2a] border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <button
            onClick={handleTestPromptWithGemini}
            disabled={isTestingPrompt}
            className="w-full bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-bold py-2.5 rounded-lg text-xs flex items-center justify-center gap-2 transition-all shadow-md active:scale-95"
          >
            <Play className="w-3.5 h-3.5" />
            <span>{isTestingPrompt ? "Evaluating with Gemini Model..." : "Run Realtime Prompt Test"}</span>
          </button>

          {testAiReply && (
            <div className="p-4 bg-indigo-950/40 border border-indigo-500/40 rounded-xl space-y-2 text-xs animate-fadeIn">
              <div className="text-[10px] font-bold text-indigo-300 uppercase tracking-wider flex items-center justify-between">
                <span className="flex items-center gap-1">
                  <Bot className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Generated AI Voice Response</span>
                </span>
                <span className="text-emerald-400 font-mono">Temp: {temperature}</span>
              </div>
              <p className="text-slate-200 leading-relaxed font-sans">{testAiReply}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
