import React, { useState } from "react";
import { Settings, CreditCard, Shield, Server, Bell, Save, Check } from "lucide-react";

export const SettingsView: React.FC = () => {
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = () => {
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="flex-1 overflow-y-auto bg-[#0b0e14] p-6 space-y-6 text-slate-200 font-sans">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Settings className="w-5 h-5 text-indigo-400" />
            <span>Telephony System Settings & Gateways</span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Twilio SIP Trunking credentials, WebSockets audio buffering, and billing plans
          </p>
        </div>

        <button
          onClick={handleSave}
          className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs px-3.5 py-2 rounded-lg flex items-center gap-1.5 transition-colors shadow-md shadow-indigo-950/40"
        >
          {savedSuccess ? <Check className="w-4 h-4 text-emerald-400" /> : <Save className="w-4 h-4" />}
          <span>{savedSuccess ? "Settings Saved!" : "Save Configuration"}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* SIP Trunking & Twilio Gateway */}
          <div className="bg-[#121620] border border-slate-800 rounded-xl p-5 space-y-4">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Server className="w-4 h-4 text-indigo-400" />
              <span>SIP Trunking & Telephony Gateway Config</span>
            </h2>

            <div className="grid grid-cols-2 gap-4 text-xs">
              <div>
                <label className="text-slate-400 block mb-1 font-medium">SIP Domain Host</label>
                <input
                  type="text"
                  defaultValue="athr-sip.gateway.internal"
                  className="w-full bg-[#181d2a] border border-slate-800 rounded-lg p-2.5 font-mono text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1 font-medium">PCM Audio Sample Rate</label>
                <select className="w-full bg-[#181d2a] border border-slate-800 rounded-lg p-2.5 font-mono text-white focus:outline-none focus:border-indigo-500">
                  <option>24000 Hz (Gemini Studio Audio)</option>
                  <option>16000 Hz (Standard Voice HD)</option>
                  <option>8000 Hz (Legacy PSTN)</option>
                </select>
              </div>
            </div>
          </div>

          {/* AI Voice Model Settings */}
          <div className="bg-[#121620] border border-slate-800 rounded-xl p-5 space-y-4">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Shield className="w-4 h-4 text-emerald-400" />
              <span>AI Agent Safety & Compliance Rules</span>
            </h2>

            <div className="space-y-3 text-xs">
              <label className="flex items-center gap-3 p-3 bg-slate-900/80 rounded-lg border border-slate-800 cursor-pointer">
                <input type="checkbox" defaultChecked className="rounded border-slate-700 bg-slate-800 text-indigo-600 focus:ring-indigo-500" />
                <div>
                  <div className="font-semibold text-white">Automatic Call Recording Disclosure</div>
                  <div className="text-slate-400 text-[11px]">Play verbal notice "This call is recorded for quality purposes" upon connection.</div>
                </div>
              </label>

              <label className="flex items-center gap-3 p-3 bg-slate-900/80 rounded-lg border border-slate-800 cursor-pointer">
                <input type="checkbox" defaultChecked className="rounded border-slate-700 bg-slate-800 text-indigo-600 focus:ring-indigo-500" />
                <div>
                  <div className="font-semibold text-white">Realtime PII Masking</div>
                  <div className="text-slate-400 text-[11px]">Redact credit card numbers and SSN from transcript logs automatically.</div>
                </div>
              </label>
            </div>
          </div>
        </div>

        {/* Billing Overview */}
        <div className="bg-[#121620] border border-slate-800 rounded-xl p-5 space-y-4">
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-amber-400" />
            <span>Subscription & Billing</span>
          </h2>

          <div className="p-4 bg-gradient-to-br from-indigo-950 to-slate-900 border border-indigo-500/30 rounded-xl space-y-2">
            <div className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider">Current Tier</div>
            <div className="text-lg font-bold text-white">ATHR Enterprise Unlimited</div>
            <div className="text-xs text-slate-300 font-mono">Includes Gemini 3.6 Flash Voice Gateway</div>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex justify-between py-1 border-b border-slate-800">
              <span className="text-slate-400">Monthly Usage</span>
              <span className="font-mono text-white font-bold">14,280 / 50,000 mins</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800">
              <span className="text-slate-400">Concurrent SIP Channels</span>
              <span className="font-mono text-emerald-400 font-bold">50 Active</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
