import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// Lazy init for Gemini AI client
function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// API Routes
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Simulate a realistic incoming customer call scenario using Gemini
app.post("/api/call/simulate", async (req, res) => {
  try {
    const { campaignName, customerName } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      // Fallback structured simulation if no API key set
      const defaultScenarios = [
        {
          customerName: customerName || "Eleanor Vance",
          phoneNumber: "+1 (555) 382-9102",
          intent: "Inquiring about account subscription upgrade & discount eligibility",
          initialMessage: "Hi there! I was trying to press 1 to speak with an agent about renewing my annual subscription.",
          sentimentScore: 15,
          emotion: "Curious",
          suggestedResponse: "Greeting warmly, acknowledge their loyalty, and check current subscription plan."
        },
        {
          customerName: customerName || "Marcus Brody",
          phoneNumber: "+1 (555) 749-2041",
          intent: "Technical issue with phone list integration",
          initialMessage: "Hello, I pressed 1 because my team is getting an error code 403 on the telephony gateway.",
          sentimentScore: -20,
          emotion: "Mildly Frustrated",
          suggestedResponse: "Apologize for the inconvenience, request account ID, and offer step-by-step diagnostic."
        },
        {
          customerName: customerName || "Sophia Martinez",
          phoneNumber: "+1 (555) 912-8833",
          intent: "Callback request regarding campaign scheduling",
          initialMessage: "Good morning! I received a call from your outbound campaign and wanted to ask a quick question.",
          sentimentScore: 40,
          emotion: "Friendly",
          suggestedResponse: "Thank them for reaching back out and review campaign details in CRM."
        }
      ];
      const selected = defaultScenarios[Math.floor(Math.random() * defaultScenarios.length)];
      return res.json({ success: true, scenario: selected });
    }

    const prompt = `You are generating a realistic call center customer simulation for an AI call center system.
Campaign context: ${campaignName || 'General Support & Inbound Sales'}.
Output a strict JSON object with these fields:
- "customerName": string (realistic full name)
- "phoneNumber": string (format like +1 (555) XXX-XXXX)
- "intent": string (short call reason summary)
- "initialMessage": string (first spoken sentence after customer pressed 1)
- "sentimentScore": number (-100 to 100)
- "emotion": string (e.g. "Frustrated", "Neutral", "Delighted", "Urgent", "Curious")
- "suggestedResponse": string (recommended agent greeting/action)`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const scenario = JSON.parse(response.text || "{}");
    return res.json({ success: true, scenario });
  } catch (error: any) {
    console.error("Error simulating call with Gemini:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to generate AI call simulation scenario.",
    });
  }
});

// Handle live turn interaction during an active call
app.post("/api/call/respond", async (req, res) => {
  try {
    const { transcriptHistory, userMessage, agentPersona, customerContext } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      // Clean fallback if API key isn't provided
      return res.json({
        success: true,
        aiAgentResponse: "Thank you for providing that detail. I've updated your record in the ATHR system. Is there anything else I can assist you with today?",
        sentimentScore: 25,
        emotion: "Satisfied",
        copilotSuggestions: [
          "Confirm account email",
          "Offer promotional discount",
          "Send SMS summary link"
        ],
        complianceCheckPassed: true,
        detectedKeywords: ["account", "update", "assistance"]
      });
    }

    const prompt = `You are an intelligent AI Call Center Agent and Real-Time Copilot supervisor.
Customer context: ${JSON.stringify(customerContext || {})}
Agent Persona/Instructions: ${agentPersona || "Professional, empathetic, efficient call center agent for ATHR."}
Previous Transcript History:
${JSON.stringify(transcriptHistory || [])}

Latest Spoken Customer Message: "${userMessage}"

Generate a JSON response with:
- "aiAgentResponse": string (natural, spoken conversational response by the AI agent, concise for voice)
- "sentimentScore": number (-100 to 100 representing customer sentiment)
- "emotion": string (e.g., "Calm", "Annoyed", "Enthusiastic", "Anxious")
- "copilotSuggestions": string array (3 quick actionable bullet suggestions for the human agent watching the live screen)
- "complianceCheckPassed": boolean (true if statement adheres to privacy & disclosure guidelines)
- "detectedKeywords": string array (key entities or intent tags detected)`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const data = JSON.parse(response.text || "{}");
    return res.json({ success: true, ...data });
  } catch (error: any) {
    console.error("Error in AI agent response endpoint:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to process call turn response.",
    });
  }
});

// Post-call Analysis and Summary endpoint
app.post("/api/call/analyze", async (req, res) => {
  try {
    const { transcript, duration, agentName, customerName } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      return res.json({
        success: true,
        summary: "Customer called regarding subscription options. Agent provided plan details and successfully answered queries. No escalation required.",
        csatScore: 4.8,
        sentiment: "Positive",
        keyTopics: ["Subscription", "Billing", "Product Demo"],
        actionItems: ["Send follow-up email with pricing PDF", "Schedule check-in call next month"],
        resolutionStatus: "Resolved"
      });
    }

    const prompt = `Analyze this completed call transcript for ATHR Call Center:
Customer: ${customerName || 'Customer'}
Agent: ${agentName || 'Daunts Agent'}
Call Duration: ${duration || '1:18'}
Transcript:
${JSON.stringify(transcript || [])}

Return a JSON object with:
- "summary": string (3-4 sentence comprehensive executive summary)
- "csatScore": number (1.0 to 5.0)
- "sentiment": string ("Positive", "Neutral", "Negative")
- "keyTopics": string array (3-5 keywords)
- "actionItems": string array (1-3 follow up steps)
- "resolutionStatus": string ("Resolved", "Escalated", "Follow-Up Needed")`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const analysis = JSON.parse(response.text || "{}");
    return res.json({ success: true, analysis });
  } catch (error: any) {
    console.error("Error analyzing call:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to analyze completed call.",
    });
  }
});

// AI Email Generator & Dispatcher endpoint
app.post("/api/email/generate", async (req, res) => {
  try {
    const { customerName, customerEmail, callSummary, actionItems, templateType } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      return res.json({
        success: true,
        email: {
          recipient: customerEmail || "customer@example.com",
          subject: `Summary of Our Recent Call - ATHR Telephony Support`,
          body: `Hi ${customerName || "Valued Customer"},\n\nThank you for speaking with us today at ATHR Call Center. Here is a brief recap of our discussion:\n\nSummary:\n${callSummary || "We reviewed your account details and confirmed your subscription active status."}\n\nNext Steps:\n${(actionItems || ["Our support team will follow up within 24 hours"]).map((item: string) => `- ${item}`).join("\n")}\n\nIf you have any further questions, simply reply to this email.\n\nBest regards,\nATHR Telephony Team`,
        }
      });
    }

    const prompt = `Generate a highly professional post-call follow-up email for ATHR Call Center.
Customer Name: ${customerName || 'Valued Customer'}
Recipient Email: ${customerEmail || 'customer@example.com'}
Call Summary: ${callSummary || 'Call resolved successfully.'}
Action Items: ${JSON.stringify(actionItems || [])}
Template Style: ${templateType || 'Post-Call Follow Up'}

Output JSON with:
- "recipient": string
- "subject": string
- "body": string (formatted plain text email body with greeting, recap bullet points, and signature)`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const emailData = JSON.parse(response.text || "{}");
    return res.json({ success: true, email: emailData });
  } catch (error: any) {
    console.error("Error generating email:", error);
    res.status(500).json({ success: false, error: error.message || "Failed to draft AI email." });
  }
});

// Email Dispatch Endpoint (Simulated Real-Time SMTP Delivery)
app.post("/api/email/send", async (req, res) => {
  try {
    const { recipient, subject, body, callId, senderName } = req.body;
    
    // Simulate SMTP network dispatch latency
    await new Promise((resolve) => setTimeout(resolve, 600));

    const emailRecord = {
      messageId: `msg-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      recipient,
      subject,
      body,
      sentAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      status: "DELIVERED",
      sender: senderName || "ATHR Telephony AI Dispatcher <dispatch@athr-telephony.internal>",
      callIdRef: callId || null
    };

    return res.json({ success: true, emailRecord });
  } catch (error: any) {
    console.error("Error sending email:", error);
    res.status(500).json({ success: false, error: "Email delivery failed." });
  }
});

// AI Agent Script Generator endpoint
app.post("/api/script/generate", async (req, res) => {
  try {
    const { campaignGoal, targetAudience, tone } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      return res.json({
        success: true,
        script: {
          title: "Inbound Assistance Script",
          systemPrompt: "You are an expert AI Voice Representative for ATHR. Greet callers warmly, verify identity, and address inquiries systematically.",
          openingGreeting: "Hello! Thanks for reaching ATHR Live Services. My name is Alex, how can I help you today?",
          objectionHandlers: [
            { objection: "I don't have time right now", response: "I completely understand! Can I send you a 30-second text summary to review later?" },
            { objection: "It's too expensive", response: "We offer flexible tiered billing options tailored specifically to team size." }
          ],
          closingStatement: "Thank you for choosing ATHR. Have a wonderful day!"
        }
      });
    }

    const prompt = `Generate a high-converting, empathetic AI Call Center Agent Script.
Campaign Goal: ${campaignGoal || 'Inbound Customer Service & Account Renewal'}
Target Audience: ${targetAudience || 'Existing enterprise clients'}
Tone: ${tone || 'Professional yet warm'}

Output JSON with:
- "title": string
- "systemPrompt": string (system instruction for Gemini voice model)
- "openingGreeting": string
- "objectionHandlers": array of objects with { "objection": string, "response": string }
- "closingStatement": string`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const script = JSON.parse(response.text || "{}");
    return res.json({ success: true, script });
  } catch (error: any) {
    console.error("Error generating script:", error);
    res.status(500).json({ success: false, error: error.message || "Script generation failed." });
  }
});

// Asterisk PBX ARI / AMI Integration & AI Agent Bridge API
app.get("/api/asterisk/status", (_req, res) => {
  res.json({
    success: true,
    asteriskVersion: "Asterisk 20.6.0-cert1 (PJSIP / ARI 3.0.0)",
    status: "ONLINE",
    ariConnected: true,
    amiConnected: true,
    activePjsipChannels: 12,
    registeredTrunks: [
      { id: "trunk-sip-us-east", provider: "Twilio Elastic SIP Trunk", status: "REACHABLE", RTT: "18ms" },
      { id: "trunk-sip-us-west", provider: "Bandwidth SIP Primary", status: "REACHABLE", RTT: "24ms" },
    ],
    aiAgentsConnected: [
      { extension: "PJSIP/ai-agent-01", name: "Gemini-Voice-Core-1", status: "BRIDGED", activeChannel: "PJSIP/ext-101-00000021" },
      { extension: "PJSIP/ai-agent-02", name: "Gemini-Voice-Core-2", status: "IDLE", activeChannel: null },
      { extension: "PJSIP/ai-agent-03", name: "Gemini-Voice-Copilot", status: "BRIDGED", activeChannel: "PJSIP/ext-104-00000028" },
    ],
    lastAriEvent: {
      event: "StasisStart",
      timestamp: new Date().toISOString(),
      channel: "PJSIP/cust-8831-0000003f",
      args: ["app=athr-ai-dispatcher", "dialplan_context=from-pstn"]
    }
  });
});

app.post("/api/asterisk/originate", async (req, res) => {
  try {
    const { endpoint, extension, callerId, campaign } = req.body;
    // Simulate Asterisk ARI originate request
    await new Promise((resolve) => setTimeout(resolve, 400));
    res.json({
      success: true,
      channelId: `PJSIP/${endpoint || "outbound"}-${Date.now().toString(36)}`,
      status: "RINGING",
      asteriskAriResponse: {
        id: `PJSIP/asterisk-ari-${Date.now()}`,
        name: `PJSIP/${endpoint || "cust"}-000000${Math.floor(Math.random()*90 + 10)}`,
        state: "Ringing",
        caller: { name: callerId || "ATHR AI Dialler", number: extension || "8005550199" },
        creationtime: new Date().toISOString()
      },
      campaign: campaign || "Default Outbound Campaign"
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: "Failed to originate Asterisk ARI channel." });
  }
});

app.post("/api/asterisk/ari-webhook", (req, res) => {
  const ariEvent = req.body;
  console.log("Received Asterisk ARI Event:", ariEvent);
  res.json({ status: "ACK", receivedAt: new Date().toISOString() });
});

// Vite Server Integration
async function start() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

start();
