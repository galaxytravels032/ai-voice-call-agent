import React, { useState } from "react";
import { History, Mic, Play, FileText, Search, Sparkles, Mail, CheckCircle2, Send, Download } from "lucide-react";
import { CompletedCallRecord } from "../types";

interface CallRecordsViewProps {
  completedCalls: CompletedCallRecord[];
  onOpenEmailSenderWithRecord?: (record: CompletedCallRecord) => void;
}

export const CallRecordsView: React.FC<CallRecordsViewProps> = ({
  completedCalls,
  onOpenEmailSenderWithRecord,
}) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeRecord, setActiveRecord] = useState<CompletedCallRecord | null>(null);
  const [sentEmailNotice, setSentEmailNotice] = useState<string | null>(null);
  const [isSendingQuickEmail, setIsSendingQuickEmail] = useState(false);

  const filtered = completedCalls.filter(
    (c) =>
      c.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.agent.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.phoneNumber.includes(searchTerm)
  );

  const handleExportCSV = () => {
    if (completedCalls.length === 0) return;
    const headers = ["ID", "Time", "Customer", "Phone Number", "Agent", "Duration", "Sentiment", "Summary"];
    const rows = completedCalls.map((c) => [
      c.id,
      `"${c.time}"`,
      `"${c.customer}"`,
      `"${c.phoneNumber}"`,
      `"${c.agent}"`,
      `"${c.duration}"`,
      `"${c.sentiment}"`,
      `"${(c.summary || "").replace(/"/g, '""')}"`
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `athr_call_records_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleQuickEmailSummary = async (rec: CompletedCallRecord) => {
    setIsSendingQuickEmail(true);
    setSentEmailNotice(null);
    try {
      const emailRecipient = `${rec.customer.toLowerCase().replace(/\s+/g, ".")}@example.com`;
      const res = await fetch("/api/email/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          recipient: emailRecipient,
          subject: `Call Summary & Recap - ATHR Support (${rec.time})`,
          body: `Hi ${rec.customer},\n\nThank you for speaking with our agent (${rec.agent}) today. Here is the AI-generated summary of your call:\n\n${rec.summary || "Call concluded successfully."}\n\nBest regards,\nATHR Telephony Team`,
          callId: rec.id,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setSentEmailNotice(`Email summary dispatched to ${emailRecipient}!`);
        setTimeout(() => setSentEmailNotice(null), 4000);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsSendingQuickEmail(false);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto bg-[#0b0e14] p-6 space-y-6 text-slate-200 font-sans">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <History className="w-5 h-5 text-indigo-400" />
            <span>Call Records & Voice Recordings</span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Full conversation transcripts, sentiment analysis, and PCM audio playback
          </p>
        </div>
      </div>

      {sentEmailNotice && (
        <div className="p-3 bg-emerald-950/50 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{sentEmailNotice}</span>
        </div>
      )}

      <div className="bg-[#121620] border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="relative w-72">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Filter by customer, phone, agent..."
              className="w-full bg-[#181d2a] border border-slate-800 rounded-lg text-xs pl-9 pr-3 py-1.5 focus:outline-none focus:border-indigo-500 text-white"
            />
          </div>

          <button
            onClick={handleExportCSV}
            disabled={completedCalls.length === 0}
            className="bg-[#181d2a] hover:bg-slate-800 text-slate-200 border border-slate-700 font-semibold text-xs px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors disabled:opacity-40"
            title="Export call records to CSV"
          >
            <Download className="w-3.5 h-3.5 text-indigo-400" />
            <span>Export CSV Report ({completedCalls.length})</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead>
              <tr className="border-b border-slate-800 text-slate-500 font-semibold uppercase tracking-wider text-[11px]">
                <th className="py-3 px-3">Time</th>
                <th className="py-3 px-3">Customer</th>
                <th className="py-3 px-3">Agent</th>
                <th className="py-3 px-3">Phone</th>
                <th className="py-3 px-3">Duration</th>
                <th className="py-3 px-3">Sentiment</th>
                <th className="py-3 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
              {filtered.map((rec) => (
                <tr key={rec.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-3 font-semibold text-white">{rec.time}</td>
                  <td className="py-3 px-3 font-sans text-slate-200">{rec.customer}</td>
                  <td className="py-3 px-3 font-sans text-slate-300">{rec.agent}</td>
                  <td className="py-3 px-3 text-slate-400">{rec.phoneNumber}</td>
                  <td className="py-3 px-3 text-emerald-400 font-bold">{rec.duration}</td>
                  <td className="py-3 px-3 font-sans">
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                      {rec.sentiment || "Positive"}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right font-sans">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => handleQuickEmailSummary(rec)}
                        title="Send AI Email Summary"
                        className="bg-purple-600/20 hover:bg-purple-600/40 text-purple-300 border border-purple-500/30 text-[11px] px-2 py-1 rounded transition-colors inline-flex items-center gap-1 font-medium"
                      >
                        <Mail className="w-3 h-3 text-purple-400" />
                        <span>Email Recap</span>
                      </button>
                      <button
                        onClick={() => setActiveRecord(rec)}
                        className="bg-indigo-600/20 hover:bg-indigo-600/40 text-indigo-300 border border-indigo-500/30 text-[11px] px-2.5 py-1 rounded transition-colors inline-flex items-center gap-1 font-medium"
                      >
                        <Play className="w-3 h-3" />
                        <span>Listen & Transcript</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {activeRecord && (
        <div className="bg-[#121620] border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="font-bold text-sm text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <span>Transcript & Analysis for {activeRecord.customer} ({activeRecord.time})</span>
            </h3>
            <button
              onClick={() => setActiveRecord(null)}
              className="text-xs text-slate-400 hover:text-white"
            >
              Hide
            </button>
          </div>

          <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 text-xs leading-relaxed text-slate-300">
            <div className="font-bold text-slate-400 uppercase text-[10px] mb-1">AI Executive Summary</div>
            <div>{activeRecord.summary || "Call resolved smoothly with positive feedback."}</div>
          </div>

          <div className="space-y-2 max-h-60 overflow-y-auto">
            {activeRecord.transcript?.map((t, idx) => (
              <div key={idx} className="p-2.5 bg-[#161b26] rounded border border-slate-800 text-xs">
                <span className="font-bold text-indigo-400">{t.speaker}:</span>{" "}
                <span className="text-slate-200">{t.text}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
