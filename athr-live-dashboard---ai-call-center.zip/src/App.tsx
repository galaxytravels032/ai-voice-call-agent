import React, { useState, useEffect } from "react";
import { Sidebar } from "./components/Sidebar";
import { Header } from "./components/Header";
import { AthrDashboard } from "./components/AthrDashboard";
import { CommandCenterView } from "./components/CommandCenterView";
import { AsteriskGatewayView } from "./components/AsteriskGatewayView";
import { CampaignsView } from "./components/CampaignsView";
import { PhoneListsView } from "./components/PhoneListsView";
import { ScriptsView } from "./components/ScriptsView";
import { CallRecordsView } from "./components/CallRecordsView";
import { EmailSenderView } from "./components/EmailSenderView";
import { AnalyticsView } from "./components/AnalyticsView";
import { SettingsView } from "./components/SettingsView";
import { SimulateCallModal } from "./components/SimulateCallModal";

import {
  ActiveCall,
  AgentStatus,
  CallCenterStats,
  CompletedCallRecord,
  NavSection,
  QueuedCall,
  SentEmailRecord
} from "./types";
import {
  initialAgents,
  initialCampaigns,
  initialCompletedCalls,
  initialPhoneLists,
  initialScripts,
  initialStats
} from "./data/initialData";

export default function App() {
  const [currentSection, setCurrentSection] = useState<NavSection>("dashboard");
  const [isSimulatorOpen, setIsSimulatorOpen] = useState(false);

  // Core Application Data State
  const [stats, setStats] = useState<CallCenterStats>(initialStats);
  const [queuedCalls, setQueuedCalls] = useState<QueuedCall[]>([]);
  const [activeCalls, setActiveCalls] = useState<ActiveCall[]>([]);
  const [agents, setAgents] = useState<AgentStatus[]>(initialAgents);
  const [completedCalls, setCompletedCalls] = useState<CompletedCallRecord[]>(initialCompletedCalls);
  const [campaigns, setCampaigns] = useState(initialCampaigns);
  const [phoneLists, setPhoneLists] = useState(initialPhoneLists);
  const [scripts, setScripts] = useState(initialScripts);
  const [sentEmails, setSentEmails] = useState<SentEmailRecord[]>([
    {
      messageId: "msg-17216401-902",
      recipient: "eleanor.vance@acme-corp.com",
      subject: "Summary of Our Recent Call - ATHR Telephony Support",
      body: "Hi Eleanor, thank you for contacting ATHR. We confirmed your subscription renewal rate at a 15% discount.",
      sentAt: "10:14 AM",
      status: "DELIVERED",
      sender: "ATHR Telephony AI Dispatcher <dispatch@athr-telephony.internal>"
    },
    {
      messageId: "msg-17216388-112",
      recipient: "marcus.brody@museum-archaeology.org",
      subject: "Ticket #4829 Tech Support Resolution",
      body: "Hello Marcus, our engineering team resolved error code 403 on your SIP Gateway.",
      sentAt: "09:42 AM",
      status: "DELIVERED",
      sender: "ATHR Telephony AI Dispatcher <dispatch@athr-telephony.internal>"
    }
  ]);

  const handleSendEmail = (newEmail: SentEmailRecord) => {
    setSentEmails((prev) => [newEmail, ...prev]);
  };

  // Live Simulation Toggle State
  const [isLiveSimActive, setIsLiveSimActive] = useState(true);

  // Update Call Center Stats whenever queues or active calls change
  useEffect(() => {
    setStats((prev) => ({
      ...prev,
      callsInQueue: queuedCalls.length,
      activeCalls: activeCalls.length,
      availableAgents: agents.filter((a) => a.status === "AVAILABLE").length,
    }));
  }, [queuedCalls, activeCalls, agents]);

  // Real-time ticker to update active call timers, waveforms, queue wait times, and idle agents
  useEffect(() => {
    const interval = setInterval(() => {
      // 1. Tick active calls duration and update dynamic live waveforms & sentiment drift
      setActiveCalls((prevCalls) =>
        prevCalls.map((call) => {
          const sentimentShift = (Math.random() - 0.48) * 4;
          const newScore = Math.max(-100, Math.min(100, (call.sentimentScore ?? 50) + sentimentShift));
          const newSentiment = newScore > 20 ? "Positive" : newScore < -20 ? "Negative" : "Neutral";

          return {
            ...call,
            durationSeconds: call.durationSeconds + 1,
            sentimentScore: Math.round(newScore),
            sentiment: newSentiment,
            audioWaveform: Array.from({ length: 10 }, () =>
              Math.floor(Math.random() * 80) + 20
            ),
            agentPitchWaveform: Array.from({ length: 10 }, () =>
              Math.floor(Math.random() * 75) + 25
            ),
          };
        })
      );

      // 2. Tick queued calls wait time
      setQueuedCalls((prevQueued) =>
        prevQueued.map((q) => ({
          ...q,
          waitTimeSeconds: q.waitTimeSeconds + 1,
        }))
      );
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  // Tick agent idle minutes every 30 seconds for AVAILABLE agents
  useEffect(() => {
    const agentIdleInterval = setInterval(() => {
      setAgents((prevAgents) =>
        prevAgents.map((agent) => {
          if (agent.status === "AVAILABLE") {
            return { ...agent, idleMinutes: (agent.idleMinutes || 0) + 1 };
          }
          return agent;
        })
      );
    }, 30000);

    return () => clearInterval(agentIdleInterval);
  }, []);

  // Live Auto-Simulation: Generate incoming calls every ~12 seconds when active
  useEffect(() => {
    if (!isLiveSimActive) return;

    const sampleCustomers = [
      { name: "Sophia Martinez", phone: "+1 (310) 849-2041", campaign: "Tier 1 Customer Support", category: "Standard" as const },
      { name: "David Kim", phone: "+1 (415) 923-8812", campaign: "Technical Support", category: "Technical" as const },
      { name: "Elena Rostova", phone: "+1 (212) 674-9930", campaign: "VIP Concierge Sales", category: "Urgent" as const },
      { name: "Carlos Mendez", phone: "+1 (702) 418-5022", campaign: "Billing & Claims", category: "Standard" as const },
      { name: "Priya Sharma", phone: "+1 (206) 555-0188", campaign: "AI Voice Copilots", category: "Technical" as const },
    ];

    const liveSimInterval = setInterval(() => {
      const randomCust = sampleCustomers[Math.floor(Math.random() * sampleCustomers.length)];
      const isUrgent = Math.random() > 0.6;

      const newQueueCall: QueuedCall = {
        id: `q-live-${Date.now()}`,
        phoneNumber: randomCust.phone,
        customerName: randomCust.name,
        queueEnteredTime: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        waitTimeSeconds: Math.floor(Math.random() * 8) + 2,
        pressedOne: true,
        campaign: randomCust.campaign,
        priority: isUrgent ? "High" : "Normal",
        category: isUrgent ? "Urgent" : randomCust.category,
      };

      setQueuedCalls((prev) => [newQueueCall, ...prev.slice(0, 9)]);
    }, 12000);

    return () => clearInterval(liveSimInterval);
  }, [isLiveSimActive]);

  // Handler: Add a new queued call
  const handleAddQueuedCall = (newQueueCall: QueuedCall) => {
    setQueuedCalls((prev) => [newQueueCall, ...prev]);
  };

  // Handler: Add a new active call
  const handleAddActiveCall = (newActiveCall: ActiveCall) => {
    setActiveCalls((prev) => [newActiveCall, ...prev]);
  };

  // Handler: Route a queued call to an agent
  const handleRouteQueueCall = (queueId: string) => {
    const targetQueue = queuedCalls.find((q) => q.id === queueId);
    if (!targetQueue) return;

    setQueuedCalls((prev) => prev.filter((q) => q.id !== queueId));

    const newActiveCall: ActiveCall = {
      id: `call-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      phoneNumber: targetQueue.phoneNumber,
      customerName: targetQueue.customerName,
      agentName: "Daunts Agent.",
      startTime: new Date().toLocaleTimeString(),
      durationSeconds: 1,
      pressedOne: true,
      status: "connected",
      sentiment: "Positive",
      sentimentScore: 50,
      queueWaitTime: `${targetQueue.waitTimeSeconds}s`,
      campaign: targetQueue.campaign,
      transcript: [
        {
          speaker: "customer",
          text: "Hello! Thanks for picking up my queued call.",
          timestamp: "0:01",
        },
      ],
      audioWaveform: [30, 50, 70, 40, 60, 80, 50, 40, 60, 30],
      agentPitchWaveform: [40, 60, 80, 50, 70, 90, 60, 50, 70, 40],
    };

    setActiveCalls((prev) => [newActiveCall, ...prev]);
  };

  // Handler: Move all queued calls to an agent group
  const handleMoveAllQueueCalls = (groupName: string) => {
    setQueuedCalls((prev) =>
      prev.map((q) => ({
        ...q,
        campaign: `${groupName}`,
      }))
    );
  };

  // Handler: Finish active call and add to Completed Calls log
  const handleFinishCallToCompleted = (activeCallObj: ActiveCall) => {
    setActiveCalls((prev) => prev.filter((c) => c.id !== activeCallObj.id));

    const durationFormatted = `${Math.floor(activeCallObj.durationSeconds / 60)}:${(
      activeCallObj.durationSeconds % 60
    )
      .toString()
      .padStart(2, "0")}`;

    const newCompletedRecord: CompletedCallRecord = {
      id: `rec-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
      phoneNumber: activeCallObj.phoneNumber,
      customer: activeCallObj.customerName,
      agent: activeCallObj.agentName,
      duration: durationFormatted,
      waitTime: activeCallObj.queueWaitTime || "0:08",
      status: "Completed",
      campaign: activeCallObj.campaign,
      sentiment: activeCallObj.sentiment,
      summary: `Call successfully concluded with ${activeCallObj.customerName}. AI Agent processed request with high satisfaction score (${activeCallObj.sentimentScore}).`,
      transcript: activeCallObj.transcript,
    };

    setCompletedCalls((prev) => [newCompletedRecord, ...prev]);
    setStats((prev) => ({
      ...prev,
      completedSessions: prev.completedSessions + 1,
      totalPanelSessions: prev.totalPanelSessions + 1,
    }));
  };

  // Actions
  const handleCleanupQueue = () => setQueuedCalls([]);
  const handleCleanupActive = () => setActiveCalls([]);

  const handleToggleAgentStatus = (agentId: string) => {
    setAgents((prev) =>
      prev.map((a) => {
        if (a.id === agentId) {
          const nextStatus = a.status === "AVAILABLE" ? "BUSY" : "AVAILABLE";
          return { ...a, status: nextStatus };
        }
        return a;
      })
    );
  };

  const handleEndCall = (callId: string) => {
    const target = activeCalls.find((c) => c.id === callId);
    if (target) {
      handleFinishCallToCompleted(target);
    } else {
      setActiveCalls((prev) => prev.filter((c) => c.id !== callId));
    }
  };

  const handleHoldCall = (callId: string) => {
    setActiveCalls((prev) =>
      prev.map((c) =>
        c.id === callId
          ? { ...c, status: c.status === "on_hold" ? "connected" : "on_hold" }
          : c
      )
    );
  };

  const handleMuteCall = (callId: string) => {
    setActiveCalls((prev) =>
      prev.map((c) =>
        c.id === callId
          ? { ...c, status: c.status === "muted" ? "connected" : "muted" }
          : c
      )
    );
  };

  const handleUpdateCallSentiment = (callId: string, delta: number) => {
    setActiveCalls((prev) =>
      prev.map((c) => {
        if (c.id === callId) {
          const newScore = Math.max(-100, Math.min(100, (c.sentimentScore ?? 50) + delta));
          const newSentiment: "Positive" | "Neutral" | "Negative" =
            newScore > 20 ? "Positive" : newScore < -20 ? "Negative" : "Neutral";
          return { ...c, sentimentScore: newScore, sentiment: newSentiment };
        }
        return c;
      })
    );
  };

  // Render view depending on navigation selection
  const renderMainContent = () => {
    switch (currentSection) {
      case "dashboard":
        return (
          <AthrDashboard
            stats={stats}
            queuedCalls={queuedCalls}
            activeCalls={activeCalls}
            agents={agents}
            completedCalls={completedCalls}
            onOpenSimulator={() => setIsSimulatorOpen(true)}
            onCleanupQueue={handleCleanupQueue}
            onCleanupActive={handleCleanupActive}
            onToggleAgentStatus={handleToggleAgentStatus}
            onEndCall={handleEndCall}
            onHoldCall={handleHoldCall}
            onMuteCall={handleMuteCall}
            onRouteQueueCall={handleRouteQueueCall}
            onMoveAllQueueCalls={handleMoveAllQueueCalls}
            onUpdateCallSentiment={handleUpdateCallSentiment}
          />
        );
      case "command_center":
        return (
          <CommandCenterView
            activeCalls={activeCalls}
            agents={agents}
            onOpenSimulator={() => setIsSimulatorOpen(true)}
            onEndCall={handleEndCall}
            onMuteCall={handleMuteCall}
          />
        );
      case "asterisk_gateway":
        return (
          <AsteriskGatewayView
            onOpenSimulator={() => setIsSimulatorOpen(true)}
            onNavigateToEmailSender={() => setCurrentSection("email_sender")}
          />
        );
      case "campaigns":
        return (
          <CampaignsView
            campaigns={campaigns}
            agents={agents}
            onTriggerCallSimulation={(customerName, phone) => {
              const availableAgent = agents.find((a) => a.status === "AVAILABLE");
              const agentName = availableAgent ? availableAgent.name : "AI Voice Bot Alpha";
              handleAddActiveCall({
                id: `call-pred-${Date.now()}`,
                customerName: customerName || "Predictive Lead",
                phoneNumber: phone || "+1 (800) 555-0199",
                agentName,
                startTime: new Date().toLocaleTimeString(),
                durationSeconds: 1,
                pressedOne: true,
                status: "connected",
                sentiment: "Positive",
                sentimentScore: 92,
                queueWaitTime: "0:02",
                audioWaveform: [30, 60, 45, 80, 50, 90, 40],
                campaign: "VIP Concierge Upgrade",
                transcript: [
                  { speaker: "system", text: "Predictive dialer initiated call", timestamp: "0:01" },
                  { speaker: "agent", text: `Hello! This is ${agentName} reaching out regarding your account.`, timestamp: "0:03" }
                ]
              });
            }}
          />
        );
      case "phone_lists":
        return <PhoneListsView phoneLists={phoneLists} />;
      case "scripts":
      case "ai_agent_scripts":
        return <ScriptsView scripts={scripts} />;
      case "email_sender":
        return <EmailSenderView sentEmails={sentEmails} onSendEmail={handleSendEmail} />;
      case "call_records":
      case "call_recordings":
        return <CallRecordsView completedCalls={completedCalls} />;
      case "analytics":
      case "reports":
        return <AnalyticsView />;
      case "billing":
      case "settings":
      case "changelog":
      case "all_tools":
      case "panel":
      default:
        return <SettingsView />;
    }
  };

  return (
    <div className="flex h-screen w-screen bg-[#0a0c10] overflow-hidden select-none">
      {/* Sidebar Navigation */}
      <Sidebar
        currentSection={currentSection}
        onSelectSection={setCurrentSection}
        activeCallsCount={activeCalls.length}
        queuedCallsCount={queuedCalls.length}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        <Header
          onOpenSimulator={() => setIsSimulatorOpen(true)}
          isLiveSimActive={isLiveSimActive}
          onToggleLiveSim={() => setIsLiveSimActive((prev) => !prev)}
        />
        {renderMainContent()}
      </div>

      {/* Interactive Call Simulator Modal */}
      <SimulateCallModal
        isOpen={isSimulatorOpen}
        onClose={() => setIsSimulatorOpen(false)}
        onAddQueuedCall={handleAddQueuedCall}
        onAddActiveCall={handleAddActiveCall}
        onFinishCallToCompleted={handleFinishCallToCompleted}
      />
    </div>
  );
}
