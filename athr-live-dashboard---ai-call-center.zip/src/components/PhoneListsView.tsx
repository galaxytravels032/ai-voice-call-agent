import React, { useState } from "react";
import { ListOrdered, Plus, Upload, CheckCircle2, AlertOctagon, PhoneCall, Search } from "lucide-react";
import { PhoneList } from "../types";

interface PhoneListsViewProps {
  phoneLists: PhoneList[];
}

export const PhoneListsView: React.FC<PhoneListsViewProps> = ({ phoneLists }) => {
  const [searchTerm, setSearchTerm] = useState("");

  return (
    <div className="flex-1 overflow-y-auto bg-[#0b0e14] p-6 space-y-6 text-slate-200 font-sans">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <ListOrdered className="w-5 h-5 text-emerald-400" />
            <span>Telephony Contact Phone Lists</span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Manage caller IDs, do-not-call scrubbers, and lead contact databases
          </p>
        </div>

        <button className="bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs px-3.5 py-2 rounded-lg flex items-center gap-1.5 transition-colors shadow-md shadow-emerald-950/40">
          <Upload className="w-4 h-4" />
          <span>Upload CSV Contact List</span>
        </button>
      </div>

      <div className="bg-[#121620] border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="relative w-64">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search phone lists..."
              className="w-full bg-[#181d2a] border border-slate-800 rounded-lg text-xs pl-9 pr-3 py-1.5 focus:outline-none focus:border-indigo-500 text-white"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead>
              <tr className="border-b border-slate-800 text-slate-500 font-semibold uppercase tracking-wider text-[11px]">
                <th className="py-3 px-3">List Name</th>
                <th className="py-3 px-3">Caller ID Assigned</th>
                <th className="py-3 px-3">Total Contacts</th>
                <th className="py-3 px-3">Valid Numbers</th>
                <th className="py-3 px-3">DNC Scrubbed</th>
                <th className="py-3 px-3">Created Date</th>
                <th className="py-3 px-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
              {phoneLists.map((list) => (
                <tr key={list.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-3 font-bold text-white font-sans">{list.name}</td>
                  <td className="py-3 px-3 text-indigo-400">{list.callerIdAssigned}</td>
                  <td className="py-3 px-3">{list.totalContacts}</td>
                  <td className="py-3 px-3 text-emerald-400">{list.validNumbers}</td>
                  <td className="py-3 px-3 text-rose-400">{list.doNotCallCount}</td>
                  <td className="py-3 px-3 text-slate-400">{list.createdDate}</td>
                  <td className="py-3 px-3">
                    <span className="px-2 py-0.5 rounded text-[10px] font-sans font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                      {list.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
