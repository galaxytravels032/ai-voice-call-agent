import { AgentStatus, CallCenterStats, Campaign, CompletedCallRecord, PhoneList, Script } from "../types";

export const initialStats: CallCenterStats = {
  totalPanelSessions: 1,
  activeSessions: 1,
  completedSessions: 0,
  verifiedSessions: 0,
  callsInQueue: 0,
  activeCalls: 0,
  availableAgents: 2,
  avgWaitTimeFormatted: "0:00",
};

export const initialAgents: AgentStatus[] = [
  {
    id: "agent-1",
    name: "Daunts Agent.",
    role: "Human Agent",
    status: "AVAILABLE",
    callsToday: 162,
    avgHandleTime: "1:45",
    csatRating: 4.9,
    avgSentimentScore: 94,
    isTopPerformer: true,
    idleMinutes: 4,
  },
  {
    id: "agent-2",
    name: "trey",
    role: "Human Agent",
    status: "AVAILABLE",
    callsToday: 21,
    avgHandleTime: "2:10",
    csatRating: 4.8,
    avgSentimentScore: 86,
    isTopPerformer: false,
    idleMinutes: 14, // >10 minutes idle alert badge
  },
  {
    id: "agent-3",
    name: "AI Voice Bot Alpha",
    role: "AI Agent",
    status: "AVAILABLE",
    callsToday: 340,
    avgHandleTime: "0:52",
    csatRating: 5.0,
    avgSentimentScore: 98,
    isTopPerformer: true,
    idleMinutes: 1,
  },
  {
    id: "agent-4",
    name: "Sarah Connors",
    role: "Supervisor",
    status: "BUSY",
    callsToday: 88,
    avgHandleTime: "3:15",
    csatRating: 4.7,
    avgSentimentScore: 89,
    isTopPerformer: false,
    idleMinutes: 0,
  }
];

export const initialCompletedCalls: CompletedCallRecord[] = [
  {
    id: "call-rec-1",
    time: "4:40:46 AM",
    phoneNumber: "+1 (555) ***-8912",
    customer: "Private Client",
    agent: "Daunts Agent.",
    duration: "0:18",
    waitTime: "1:23",
    status: "Completed",
    campaign: "Inbound Support Primary",
    sentiment: "Positive",
    summary: "Customer called to verify business operating hours during holiday weekend. Agent provided exact schedule.",
    transcript: [
      { speaker: "Customer", text: "Hi, I just wanted to check if your support desk is open tomorrow?", timestamp: "0:02" },
      { speaker: "Daunts Agent.", text: "Hello! Yes, our support team is active 24/7. Is there anything else I can help with?", timestamp: "0:08" },
      { speaker: "Customer", text: "That's wonderful, thanks so much!", timestamp: "0:15" }
    ]
  },
  {
    id: "call-rec-2",
    time: "6:43:48 AM",
    phoneNumber: "Unknown",
    customer: "INBOUND",
    agent: "Daunts Agent.",
    duration: "1:18",
    waitTime: "0:36",
    status: "Completed",
    campaign: "ATHR Core Inbound",
    sentiment: "Positive",
    summary: "Customer requested account reset link. AI Agent sent link via SMS after identity confirmation.",
    transcript: [
      { speaker: "Customer", text: "I pressed 1 because I locked myself out of the dashboard.", timestamp: "0:05" },
      { speaker: "Daunts Agent.", text: "No worries at all! I've sent a 1-time reset PIN to your registered mobile device.", timestamp: "0:25" },
      { speaker: "Customer", text: "Got it! Thanks for the fast assistance.", timestamp: "1:10" }
    ]
  },
  {
    id: "call-rec-3",
    time: "6:42:22 AM",
    phoneNumber: "Unknown",
    customer: "INBOUND",
    agent: "Daunts Agent.",
    duration: "0:14",
    waitTime: "0:12",
    status: "Completed",
    campaign: "ATHR Core Inbound",
    sentiment: "Neutral",
    summary: "Brief inquiry regarding callback option after pressing 1.",
    transcript: [
      { speaker: "Customer", text: "Testing the IVR routing, thanks!", timestamp: "0:02" },
      { speaker: "Daunts Agent.", text: "You're welcome! System is operating normally.", timestamp: "0:08" }
    ]
  },
  {
    id: "call-rec-4",
    time: "5:23:54 AM",
    phoneNumber: "Unknown",
    customer: "INBOUND",
    agent: "Daunts Agent.",
    duration: "15:06",
    waitTime: "0:09",
    status: "Completed",
    campaign: "VIP Concierge",
    sentiment: "Positive",
    summary: "In-depth consultation for ATHR Live API integration and Twilio SIP trunking configuration.",
    transcript: [
      { speaker: "Customer", text: "We need to connect 50 concurrent agents to the ATHR Live dispatch engine.", timestamp: "0:15" },
      { speaker: "Daunts Agent.", text: "Excellent! Let's walk through the WebRTC gateway and API secret provisions.", timestamp: "1:20" }
    ]
  },
  {
    id: "call-rec-5",
    time: "5:00:35 AM",
    phoneNumber: "Unknown",
    customer: "INBOUND",
    agent: "Daunts Agent.",
    duration: "10:59",
    waitTime: "0:08",
    status: "Completed",
    campaign: "ATHR Core Inbound",
    sentiment: "Positive",
    summary: "Resolved billing invoice clarification for enterprise subscription tier.",
    transcript: [
      { speaker: "Customer", text: "Can you break down the usage-based voice minutes on invoice #4920?", timestamp: "0:20" },
      { speaker: "Daunts Agent.", text: "Certainly! The breakdown includes 4,200 inbound minutes and zero setup fees.", timestamp: "2:10" }
    ]
  },
  {
    id: "call-rec-6",
    time: "4:17:26 AM",
    phoneNumber: "Unknown",
    customer: "INBOUND",
    agent: "Daunts Agent.",
    duration: "13:58",
    waitTime: "0:10",
    status: "Completed",
    campaign: "ATHR Core Inbound",
    sentiment: "Positive",
    summary: "Technical diagnostic regarding voice quality and WebSockets audio frame size.",
    transcript: [
      { speaker: "Customer", text: "We noticed small jitter during peak hours.", timestamp: "0:30" },
      { speaker: "Daunts Agent.", text: "Recommended lowering packet size to 20ms PCM buffer and enabling WebRTC jitter buffer.", timestamp: "3:10" }
    ]
  },
  {
    id: "call-rec-7",
    time: "1:01:10 AM",
    phoneNumber: "Unknown",
    customer: "INBOUND",
    agent: "Daunts Agent.",
    duration: "32:20",
    waitTime: "0:07",
    status: "Completed",
    campaign: "VIP Concierge",
    sentiment: "Positive",
    summary: "Full onboarding walkthrough and live AI Agent Script tuning with customer supervisor.",
    transcript: [
      { speaker: "Customer", text: "We want our AI agents to speak with a warm neutral tone and handle pricing objections.", timestamp: "1:00" },
      { speaker: "Daunts Agent.", text: "Configured system prompt using Gemini 3.6 Flash model with objection handling trees.", timestamp: "5:00" }
    ]
  }
];

export const initialCampaigns: Campaign[] = [
  {
    id: "camp-1",
    name: "ATHR Core Inbound",
    type: "Inbound",
    status: "Active",
    completionPercentage: 87,
    totalLeads: 12500,
    dialedCount: 10875,
    connectedCount: 9200,
    convertedCount: 3840,
    assignedAgentIds: ["agent-1", "agent-2", "agent-3"]
  },
  {
    id: "camp-2",
    name: "VIP Concierge Upgrade",
    type: "Predictive Outbound",
    status: "Active",
    completionPercentage: 64,
    totalLeads: 3200,
    dialedCount: 2048,
    connectedCount: 1890,
    convertedCount: 810,
    assignedAgentIds: ["agent-1", "agent-4"]
  },
  {
    id: "camp-3",
    name: "Q3 Renewal Outreach",
    type: "Power Dialer",
    status: "Paused",
    completionPercentage: 42,
    totalLeads: 850,
    dialedCount: 357,
    connectedCount: 310,
    convertedCount: 145,
    assignedAgentIds: ["agent-2"]
  }
];

export const initialPhoneLists: PhoneList[] = [
  {
    id: "list-1",
    name: "Enterprise Accounts Q3",
    totalContacts: 4500,
    validNumbers: 4410,
    doNotCallCount: 90,
    createdDate: "2026-07-15",
    status: "Ready",
    callerIdAssigned: "+1 (800) 555-ATHR"
  },
  {
    id: "list-2",
    name: "Inbound Callback Queue Contacts",
    totalContacts: 1200,
    validNumbers: 1195,
    doNotCallCount: 5,
    createdDate: "2026-07-20",
    status: "Ready",
    callerIdAssigned: "+1 (888) 321-0099"
  }
];

export const initialScripts: Script[] = [
  {
    id: "script-1",
    title: "ATHR AI Agent Primary Prompt",
    type: "AI Agent Prompt",
    version: "v3.2",
    lastUpdated: "2026-07-21",
    systemPrompt: "You are the primary AI Voice Representative for ATHR Call Center. You speak with natural confidence, high clarity, and polite efficiency.",
    openingGreeting: "Thank you for calling ATHR! You've connected with our AI Assistance desk. How can I help you today?",
    objectionHandlers: [
      { objection: "I want a real human agent", response: "I completely understand! I can transfer you immediately to an available agent, or if your request is quick, I can answer it right away. What works best for you?" },
      { objection: "Why am I in a queue?", response: "We are connecting callers in the order received to ensure full attention. You pressed 1 and are next in line!" }
    ],
    closingStatement: "Thank you for contacting ATHR. Have a productive day ahead!",
    assignedCampaign: "ATHR Core Inbound"
  }
];
