import React, { useState, useEffect, useRef } from "react";
import {
  X,
  Phone,
  PhoneCall,
  Mic,
  MicOff,
  Bot,
  Send,
  Sparkles,
  Volume2,
  VolumeX,
  CheckCircle2,
  AlertCircle
} from "lucide-react";
import { ActiveCall, QueuedCall } from "../types";
import { speakTextAloud, createSpeechRecognizer } from "../utils/speechUtils";
import { playCallConnectChime, playCallEndChime, playDtmfTone } from "../utils/audioSynth";

interface SimulateCallModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddQueuedCall: (call: QueuedCall) => void;
  onAddActiveCall: (call: ActiveCall) => void;
  onFinishCallToCompleted: (call: ActiveCall) => void;
}

export const SimulateCallModal: React.FC<SimulateCallModalProps> = ({
  isOpen,
  onClose,
  onAddQueuedCall,
  onAddActiveCall,
  onFinishCallToCompleted,
}) => {
  if (!isOpen) return null;

  const [step, setStep] = useState<"setup" | "ivr" | "connected">("setup");
  const [callerName, setCallerName] = useState("Eleanor Vance");
  const [phoneNumber, setPhoneNumber] = useState("+1 (555) 382-9102");
  const [campaign, setCampaign] = useState("ATHR Core Inbound");
  const [loadingScenario, setLoadingScenario] = useState(false);

  // Voice TTS & Mic state
  const [isTtsEnabled, setIsTtsEnabled] = useState(true);
  const [isListeningMic, setIsListeningMic] = useState(false);
  const recognizerRef = useRef<any>(null);

  // Active call state
  const [activeCallObj, setActiveCallObj] = useState<ActiveCall | null>(null);
  const [userSpeechInput, setUserSpeechInput] = useState("");
  const [isSendingTurn, setIsSendingTurn] = useState(false);

  // Cleanup speech synthesis and mic on unmount or close
  useEffect(() => {
    return () => {
      if (recognizerRef.current) {
        try { recognizerRef.current.stop(); } catch (e) {}
      }
      if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Toggle Microphone Speech Recognition
  const toggleMicrophone = () => {
    if (isListeningMic) {
      if (recognizerRef.current) {
        try { recognizerRef.current.stop(); } catch (e) {}
      }
      setIsListeningMic(false);
    } else {
      const rec = createSpeechRecognizer(
        (transcript, isFinal) => {
          setUserSpeechInput(transcript);
        },
        (err) => {
          console.warn("Speech Rec Error:", err);
          setIsListeningMic(false);
        }
      );
      if (rec) {
        try {
          rec.start();
          recognizerRef.current = rec;
          setIsListeningMic(true);
        } catch (e) {
          console.error(e);
        }
      } else {
        alert("Web Speech API is not supported in this browser. You can type your voice input!");
      }
    }
  };

  // Auto generate AI scenario using server backend
  const handleGenerateScenario = async () => {
    setLoadingScenario(true);
    try {
      const res = await fetch("/api/call/simulate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ campaignName: campaign, customerName: callerName }),
      });
      const data = await res.json();
      if (data.success && data.scenario) {
        setCallerName(data.scenario.customerName);
        setPhoneNumber(data.scenario.phoneNumber);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingScenario(false);
    }
  };

  // Step 1: Start IVR Call
  const handleInitiateCall = () => {
    playCallConnectChime();
    setStep("ivr");
  };

  // Step 2: Press 1 on IVR
  const handlePressOne = () => {
    playDtmfTone("1");
    playCallConnectChime();

    const callId = `call-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const initialGreeting = "Hello Eleanor! Thanks for calling ATHR Services. How can I help you today?";

    if (isTtsEnabled) {
      speakTextAloud(initialGreeting);
    }

    const newActive: ActiveCall = {
      id: callId,
      phoneNumber,
      customerName: callerName,
      agentName: "Daunts Agent. (AI Copilot Active)",
      startTime: new Date().toLocaleTimeString(),
      durationSeconds: 12,
      pressedOne: true,
      status: "connected",
      sentiment: "Positive",
      sentimentScore: 45,
      queueWaitTime: "0:04",
      campaign,
      transcript: [
        {
          speaker: "customer",
          text: "Hi there! I pressed 1 to speak with support regarding my account.",
          timestamp: "0:02",
        },
        {
          speaker: "agent",
          text: initialGreeting,
          timestamp: "0:06",
        },
      ],
      audioWaveform: [40, 70, 90, 50, 30, 80, 60, 40, 90, 30],
      copilotSuggestions: [
        "Acknowledge loyalty account",
        "Offer 15% renewal discount",
        "Verify contact email address"
      ]
    };

    setActiveCallObj(newActive);
    onAddActiveCall(newActive);
    setStep("connected");
  };

  // Step 3: Send turn conversation to Gemini API
  const handleSendTurn = async () => {
    if (!userSpeechInput.trim() || !activeCallObj) return;

    const userMsg = userSpeechInput.trim();
    setUserSpeechInput("");
    setIsSendingTurn(true);

    // Stop mic temporarily while AI responds
    if (isListeningMic && recognizerRef.current) {
      try { recognizerRef.current.stop(); } catch (e) {}
      setIsListeningMic(false);
    }

    // Append user message locally
    const updatedTranscript = [
      ...activeCallObj.transcript,
      {
        speaker: "customer" as const,
        text: userMsg,
        timestamp: `${Math.floor(activeCallObj.durationSeconds / 60)}:${(
          activeCallObj.durationSeconds % 60
        )
          .toString()
          .padStart(2, "0")}`,
      },
    ];

    try {
      const res = await fetch("/api/call/respond", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          transcriptHistory: updatedTranscript,
          userMessage: userMsg,
          customerContext: { name: activeCallObj.customerName, phone: activeCallObj.phoneNumber },
        }),
      });

      const data = await res.json();
      const aiText = data.aiAgentResponse || "Thank you. I have recorded that information for your account.";

      // Speak AI response out loud if TTS enabled!
      if (isTtsEnabled) {
        speakTextAloud(aiText);
      }

      const finalTranscript = [
        ...updatedTranscript,
        {
          speaker: "agent" as const,
          text: aiText,
          timestamp: `${Math.floor((activeCallObj.durationSeconds + 4) / 60)}:${(
            (activeCallObj.durationSeconds + 4) % 60
          )
            .toString()
            .padStart(2, "0")}`,
        },
      ];

      const updatedCall: ActiveCall = {
        ...activeCallObj,
        durationSeconds: activeCallObj.durationSeconds + 8,
        sentimentScore: data.sentimentScore ?? 35,
        transcript: finalTranscript,
        copilotSuggestions: data.copilotSuggestions || activeCallObj.copilotSuggestions,
        audioWaveform: Array.from({ length: 10 }, () => Math.floor(Math.random() * 80) + 20),
      };

      setActiveCallObj(updatedCall);
    } catch (e) {
      console.error(e);
    } finally {
      setIsSendingTurn(false);
    }
  };

  // Step 4: Finish call & append to Completed Calls
  const handleFinishCall = () => {
    playCallEndChime();
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
    if (activeCallObj) {
      onFinishCallToCompleted(activeCallObj);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 z-50 text-slate-200">
      <div className="bg-[#121620] border border-slate-800 rounded-2xl w-full max-w-2xl p-6 shadow-2xl space-y-5 relative">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
              <PhoneCall className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-lg text-white">Live AI Call Simulator</h2>
              <p className="text-xs text-slate-400">Test Gemini Voice Routing & Realtime Dashboard Integration</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step 1: Call Setup */}
        {step === "setup" && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-slate-400 block mb-1">Customer Name</label>
                <input
                  type="text"
                  value={callerName}
                  onChange={(e) => setCallerName(e.target.value)}
                  className="w-full bg-[#181d2a] border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-400 block mb-1">Phone Number</label>
                <input
                  type="text"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full bg-[#181d2a] border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 font-mono"
                />
              </div>
            </div>

            <div className="flex items-center justify-between bg-slate-900/80 p-3 rounded-lg border border-slate-800">
              <div className="text-xs text-slate-300">
                <span>Want a dynamic scenario generated by Gemini?</span>
              </div>
              <button
                onClick={handleGenerateScenario}
                disabled={loadingScenario}
                className="bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300 border border-indigo-500/40 text-xs px-3 py-1.5 rounded-lg flex items-center gap-1.5 font-medium transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{loadingScenario ? "Generating..." : "Generate Scenario"}</span>
              </button>
            </div>

            <button
              onClick={handleInitiateCall}
              className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold py-2.5 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 text-sm"
            >
              <Phone className="w-4 h-4" />
              <span>Dial Inbound Hotline</span>
            </button>
          </div>
        )}

        {/* Step 2: IVR Keypad - Press 1 */}
        {step === "ivr" && (
          <div className="py-6 flex flex-col items-center text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-amber-500/10 border border-amber-500/40 flex items-center justify-center text-amber-400 animate-pulse">
              <Volume2 className="w-8 h-8" />
            </div>
            <div>
              <div className="text-lg font-bold text-white">Interactive IVR Menu</div>
              <div className="text-xs text-slate-400 max-w-sm mt-1">
                "Thank you for calling ATHR Live. Press 1 to speak directly with an active agent or AI voice bot."
              </div>
            </div>

            <button
              onClick={handlePressOne}
              className="bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-lg px-8 py-4 rounded-2xl shadow-xl transition-transform active:scale-95 flex items-center gap-3"
            >
              <span className="w-8 h-8 rounded-full bg-black/20 flex items-center justify-center text-black">1</span>
              <span>Press Key '1' to Connect</span>
            </button>
          </div>
        )}

        {/* Step 3: Active Call Screen with Live Gemini Response Stream */}
        {step === "connected" && activeCallObj && (
          <div className="space-y-4">
            {/* Live Status Header */}
            <div className="bg-[#181d2a] border border-emerald-500/40 rounded-xl p-3 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-emerald-400 animate-ping"></div>
                <div>
                  <div className="text-xs font-bold text-white">{activeCallObj.customerName}</div>
                  <div className="text-[10px] text-slate-400 font-mono">{activeCallObj.phoneNumber}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs font-mono font-bold text-emerald-400">
                  {Math.floor(activeCallObj.durationSeconds / 60)}:
                  {(activeCallObj.durationSeconds % 60).toString().padStart(2, "0")}
                </div>
                <div className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-semibold border border-emerald-500/30">
                  Connected & Audio Active
                </div>
              </div>
            </div>

            {/* Transcript Log */}
            <div className="bg-[#0e1118] border border-slate-800 rounded-xl p-3 max-h-48 overflow-y-auto space-y-2 text-xs">
              {activeCallObj.transcript.map((t, idx) => (
                <div
                  key={idx}
                  className={`p-2.5 rounded-lg border ${
                    t.speaker === "customer"
                      ? "bg-slate-900 border-slate-800 text-slate-200"
                      : "bg-indigo-950/40 border-indigo-800/60 text-indigo-100 ml-4"
                  }`}
                >
                  <div className="flex items-center justify-between text-[10px] text-slate-500 mb-1 font-mono">
                    <span className="font-bold text-slate-300 capitalize">{t.speaker}</span>
                    <span>{t.timestamp}</span>
                  </div>
                  <div>{t.text}</div>
                </div>
              ))}
              {isSendingTurn && (
                <div className="text-xs text-indigo-400 font-mono animate-pulse p-2">
                  Gemini AI Agent is formulating voice response...
                </div>
              )}
            </div>

            {/* Copilot Suggestions Box */}
            <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl space-y-1.5">
              <div className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3 h-3" />
                <span>AI Live Agent Copilot Suggestions</span>
              </div>
              <div className="flex flex-wrap gap-2 text-xs">
                {activeCallObj.copilotSuggestions?.map((sug, i) => (
                  <span
                    key={i}
                    className="bg-indigo-500/10 text-indigo-300 border border-indigo-500/30 px-2.5 py-1 rounded-md"
                  >
                    💡 {sug}
                  </span>
                ))}
              </div>
            </div>

            {/* Speech Simulator Input & Live Mic Control */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-[11px]">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={toggleMicrophone}
                    className={`px-3 py-1 rounded-lg border text-xs font-semibold flex items-center gap-1.5 transition-all ${
                      isListeningMic
                        ? "bg-rose-500/20 text-rose-300 border-rose-500/50 animate-pulse"
                        : "bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700"
                    }`}
                  >
                    {isListeningMic ? <Mic className="w-3.5 h-3.5 text-rose-400" /> : <MicOff className="w-3.5 h-3.5 text-slate-400" />}
                    <span>{isListeningMic ? "Listening to Your Mic..." : "Speak via Mic"}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsTtsEnabled(!isTtsEnabled)}
                    className={`px-2.5 py-1 rounded-lg border text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                      isTtsEnabled
                        ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
                        : "bg-slate-800 text-slate-400 border-slate-700"
                    }`}
                  >
                    {isTtsEnabled ? <Volume2 className="w-3.5 h-3.5 text-emerald-400" /> : <VolumeX className="w-3.5 h-3.5 text-slate-400" />}
                    <span>{isTtsEnabled ? "AI Voice Out loud" : "Voice Muted"}</span>
                  </button>
                </div>

                <span className="text-slate-400 text-[10px]">Web Speech API & Gemini Live Proxy</span>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={userSpeechInput}
                  onChange={(e) => setUserSpeechInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSendTurn()}
                  placeholder={
                    isListeningMic
                      ? "Listening to voice... speak now!"
                      : "Type customer response or click 'Speak via Mic'..."
                  }
                  className="flex-1 bg-[#181d2a] border border-slate-800 text-xs text-white rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-indigo-500"
                />
                <button
                  onClick={handleSendTurn}
                  disabled={isSendingTurn || !userSpeechInput.trim()}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white p-2.5 rounded-xl transition-all disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Finish Call */}
            <button
              onClick={handleFinishCall}
              className="w-full bg-rose-600 hover:bg-rose-500 text-white font-bold py-2.5 rounded-xl transition-colors text-xs flex items-center justify-center gap-2"
            >
              <span>Hang Up & Save to ATHR Completed Log</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
