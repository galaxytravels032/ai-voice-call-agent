import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Users,
  Activity,
  CheckCircle2,
  ShieldCheck,
  ChevronDown,
  Hourglass,
  Phone,
  User,
  Clock,
  Trash2,
  Play,
  FileText,
  PhoneOff,
  Volume2,
  VolumeX,
  PhoneForwarded,
  Sparkles,
  Plus,
  X,
  CheckSquare,
  Square,
  Layers,
  Award,
  Mic,
  Bot,
  FolderOutput,
  AlertTriangle,
  Check,
  TrendingUp,
  Download,
  Flame,
  Wrench,
  Tag
} from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip as RechartsTooltip,
  CartesianGrid,
} from "recharts";
import { D3SentimentGauge } from "./D3SentimentGauge";
import { playCallEndChime } from "../utils/audioSynth";
import {
  ActiveCall,
  AgentStatus,
  CallCenterStats,
  CompletedCallRecord,
  LayoutMode,
  QueuedCall
} from "../types";

interface AthrDashboardProps {
  stats: CallCenterStats;
  queuedCalls: QueuedCall[];
  activeCalls: ActiveCall[];
  agents: AgentStatus[];
  completedCalls: CompletedCallRecord[];
  onOpenSimulator: () => void;
  onCleanupQueue: () => void;
  onCleanupActive: () => void;
  onToggleAgentStatus: (agentId: string) => void;
  onEndCall: (callId: string) => void;
  onHoldCall: (callId: string) => void;
  onMuteCall: (callId: string) => void;
  onRouteQueueCall: (queueId: string) => void;
  onSelectCallRecord?: (record: CompletedCallRecord) => void;
  onMoveAllQueueCalls?: (groupName: string) => void;
  onUpdateCallSentiment?: (callId: string, delta: number) => void;
}

// AI-based Call Classifier Helper
export const getAICategoryForCall = (call: {
  priority?: string;
  waitTimeSeconds?: number;
  campaign?: string;
  customerName?: string;
  phoneNumber?: string;
  category?: "Urgent" | "Standard" | "Technical";
}): "Urgent" | "Standard" | "Technical" => {
  if (call.category) return call.category;
  const campaign = (call.campaign || "").toLowerCase();
  const name = (call.customerName || "").toLowerCase();
  const wait = call.waitTimeSeconds || 0;

  if (
    call.priority === "High" ||
    call.priority === "VIP" ||
    wait > 60 ||
    campaign.includes("vip") ||
    name.includes("urgent") ||
    name.includes("emergency")
  ) {
    return "Urgent";
  }
  if (
    campaign.includes("tech") ||
    campaign.includes("gateway") ||
    campaign.includes("support") ||
    name.includes("tech") ||
    name.includes("sip") ||
    name.includes("api")
  ) {
    return "Technical";
  }
  return "Standard";
};

export const AthrDashboard: React.FC<AthrDashboardProps> = ({
  stats,
  queuedCalls,
  activeCalls,
  agents,
  completedCalls,
  onOpenSimulator,
  onCleanupQueue,
  onCleanupActive,
  onToggleAgentStatus,
  onEndCall,
  onHoldCall,
  onMuteCall,
  onRouteQueueCall,
  onSelectCallRecord,
  onMoveAllQueueCalls,
  onUpdateCallSentiment,
}) => {
  const [layoutMode, setLayoutMode] = useState<LayoutMode>("columns");
  const [selectedRecord, setSelectedRecord] = useState<CompletedCallRecord | null>(null);
  const [selectedCallIds, setSelectedCallIds] = useState<string[]>([]);
  const [showClearQueueModal, setShowClearQueueModal] = useState<boolean>(false);
  const [selectedAgentGroup, setSelectedAgentGroup] = useState<string>("Tier 1 Customer Support");
  const [isGroupMovedToast, setIsGroupMovedToast] = useState<string | null>(null);

  // Count agents in AVAILABLE status idle for over 10 minutes
  const idleAlertAgents = agents.filter(
    (a) => a.status === "AVAILABLE" && (a.idleMinutes || 0) >= 10
  );

  // Handler: Export JSON summary of agent metrics for current day
  const handleExportAgentMetricsReport = () => {
    const dateStr = new Date().toISOString().split("T")[0];
    const reportData = {
      reportTitle: "ATHR Telephony Agent Shift Performance Report",
      generatedAt: new Date().toISOString(),
      reportDate: dateStr,
      summary: {
        totalAgents: agents.length,
        availableAgents: agents.filter((a) => a.status === "AVAILABLE").length,
        busyAgents: agents.filter((a) => a.status === "BUSY").length,
        idleAlertAgents: idleAlertAgents.length,
      },
      agents: agents.map((agent) => ({
        id: agent.id,
        name: agent.name,
        role: agent.role,
        status: agent.status,
        callsToday: agent.callsToday,
        avgHandleTime: agent.avgHandleTime,
        csatRating: agent.csatRating,
        avgSentimentScore: agent.avgSentimentScore ?? 90,
        idleMinutes: agent.idleMinutes ?? 0,
        idleAlert: agent.status === "AVAILABLE" && (agent.idleMinutes || 0) >= 10,
        isTopPerformer: !!agent.isTopPerformer,
      })),
    };

    const jsonBlob = new Blob([JSON.stringify(reportData, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(jsonBlob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `agent-metrics-report-${dateStr}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Incoming call volume trend data over last 60 minutes
  const callVolumeTrends60Min = [
    { time: "60m ago", incoming: 18, active: 3 },
    { time: "50m ago", incoming: 22, active: 5 },
    { time: "40m ago", incoming: 29, active: 8 },
    { time: "30m ago", incoming: 34, active: 10 },
    { time: "20m ago", incoming: 28, active: 7 },
    { time: "10m ago", incoming: 41, active: 12 },
    { time: "Now", incoming: 38 + activeCalls.length + queuedCalls.length, active: activeCalls.length },
  ];

  // Sync selection when active calls change
  useEffect(() => {
    setSelectedCallIds((prev) => prev.filter((id) => activeCalls.some((c) => c.id === id)));
  }, [activeCalls]);

  const handleToggleSelectAll = () => {
    if (selectedCallIds.length === activeCalls.length) {
      setSelectedCallIds([]);
    } else {
      setSelectedCallIds(activeCalls.map((c) => c.id));
    }
  };

  const handleToggleSelectCall = (callId: string) => {
    setSelectedCallIds((prev) =>
      prev.includes(callId) ? prev.filter((id) => id !== callId) : [...prev, callId]
    );
  };

  const handleBulkEndCalls = () => {
    if (selectedCallIds.length === 0) return;
    playCallEndChime();
    selectedCallIds.forEach((id) => onEndCall(id));
    setSelectedCallIds([]);
  };

  const handleBulkMuteCalls = () => {
    if (selectedCallIds.length === 0) return;
    selectedCallIds.forEach((id) => onMuteCall(id));
  };

  const handleBulkHoldCalls = () => {
    if (selectedCallIds.length === 0) return;
    selectedCallIds.forEach((id) => onHoldCall(id));
  };

  // Layout grid CSS mappings
  const gridClasses = {
    grid: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
    columns: "grid grid-cols-1 lg:grid-cols-3 gap-4",
    focus: "grid grid-cols-1 lg:grid-cols-[1.5fr_1.5fr_1fr] gap-4",
    compact: "grid grid-cols-1 md:grid-cols-3 gap-2",
  }[layoutMode];

  return (
    <div className="flex-1 overflow-y-auto bg-[#0b0e14] p-6 space-y-6 text-slate-200 font-sans">
      {/* Page Title & Layout Switcher */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <span>ATHR Live Dashboard</span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              v2.8 Live
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time call center monitoring and agent oversight
          </p>
        </div>

        {/* Layout Buttons matching Screenshot */}
        <div className="flex items-center gap-1.5 bg-[#121620] p-1 rounded-lg border border-slate-800/80 self-start md:self-auto text-xs font-medium">
          <span className="px-2 text-[11px] text-slate-500 font-semibold">Layout:</span>
          {(["grid", "columns", "focus", "compact"] as LayoutMode[]).map((mode) => (
            <button
              key={mode}
              onClick={() => setLayoutMode(mode)}
              className={`px-3 py-1 rounded-md capitalize transition-all ${
                layoutMode === mode
                  ? "bg-slate-800 text-white font-semibold shadow-sm border border-slate-700/60"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40"
              }`}
            >
              {mode}
            </button>
          ))}
        </div>
      </div>

      {/* Top 4 Panel Sessions Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Panel Sessions */}
        <div className="bg-[#121620] border border-slate-800/80 rounded-xl p-4 flex items-center justify-between shadow-sm">
          <div>
            <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wide">
              Total Panel Sessions
            </div>
            <div className="text-2xl font-bold text-white mt-1">
              {stats.totalPanelSessions}
            </div>
          </div>
          <div className="w-10 h-10 rounded-lg bg-slate-800/80 border border-slate-700/50 flex items-center justify-center text-slate-400">
            <Users className="w-5 h-5" />
          </div>
        </div>

        {/* Active Sessions */}
        <div className="bg-[#121620] border border-slate-800/80 rounded-xl p-4 flex items-center justify-between shadow-sm">
          <div>
            <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wide">
              Active Sessions
            </div>
            <div className="text-2xl font-bold text-emerald-400 mt-1 flex items-center gap-2">
              <span>{stats.activeSessions}</span>
            </div>
          </div>
          <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 relative">
            <Activity className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
          </div>
        </div>

        {/* Completed Sessions */}
        <div className="bg-[#121620] border border-slate-800/80 rounded-xl p-4 flex items-center justify-between shadow-sm">
          <div>
            <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wide">
              Completed Sessions
            </div>
            <div className="text-2xl font-bold text-white mt-1">
              {stats.completedSessions}
            </div>
          </div>
          <div className="w-10 h-10 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        {/* Verified Sessions */}
        <div className="bg-[#121620] border border-slate-800/80 rounded-xl p-4 flex items-center justify-between shadow-sm">
          <div>
            <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wide">
              Verified Sessions
            </div>
            <div className="text-2xl font-bold text-white mt-1">
              {stats.verifiedSessions}
            </div>
          </div>
          <div className="w-10 h-10 rounded-lg bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
            <ShieldCheck className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Controls Bar */}
      <div className="bg-[#121620] border border-slate-800/80 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-white">ATHR Live Dashboard</h2>
          <p className="text-xs text-slate-400">Real-time call center monitoring and agent oversight</p>
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          {/* Balanced Dropdown */}
          <div className="relative inline-block text-left">
            <button className="bg-[#1a1f2c] border border-slate-700 text-slate-200 px-3 py-1.5 rounded-md flex items-center gap-2 hover:bg-slate-800 font-medium transition-colors">
              <span>Balanced</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>
          </div>

          {/* Live Badge Pill */}
          <div className="bg-emerald-500/15 border border-emerald-500/40 text-emerald-400 px-2.5 py-1.5 rounded-md font-semibold flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>Live</span>
          </div>

          {/* Cleanup Queue Button */}
          <button
            onClick={onCleanupQueue}
            className="bg-[#1a1f2c] hover:bg-slate-800 border border-slate-700 text-slate-300 px-3 py-1.5 rounded-md transition-colors flex items-center gap-1.5 font-medium"
          >
            <Trash2 className="w-3.5 h-3.5 text-slate-400" />
            <span>Cleanup Queue</span>
          </button>

          {/* Cleanup Active Button */}
          <button
            onClick={onCleanupActive}
            className="bg-[#1a1f2c] hover:bg-slate-800 border border-slate-700 text-slate-300 px-3 py-1.5 rounded-md transition-colors flex items-center gap-1.5 font-medium"
          >
            <Trash2 className="w-3.5 h-3.5 text-slate-400" />
            <span>Cleanup Active</span>
          </button>

          {/* Simulate Call Button */}
          <button
            onClick={onOpenSimulator}
            className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold px-3 py-1.5 rounded-md transition-all flex items-center gap-1.5 shadow-md shadow-indigo-950/40"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Simulate Call</span>
          </button>
        </div>
      </div>

      {/* 60-Minute Real-Time Incoming Call Volume Line Chart */}
      <div className="bg-[#121620] border border-slate-800/80 rounded-xl p-4 space-y-3 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/60 pb-2.5">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <TrendingUp className="w-4 h-4" />
            </span>
            <div>
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                Incoming Call Volume Trend (Last 60 Minutes)
              </h3>
              <p className="text-[11px] text-slate-400">Real-time incoming telephony traffic & active concurrency monitoring</p>
            </div>
          </div>
          <div className="flex items-center gap-3 text-[11px] font-mono shrink-0">
            <span className="flex items-center gap-1.5 text-emerald-400 font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span> Incoming Rate
            </span>
            <span className="flex items-center gap-1.5 text-indigo-400 font-semibold">
              <span className="w-2 h-2 rounded-full bg-indigo-400"></span> Active Sessions
            </span>
            <span className="text-xs font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
              Peak: 45 calls/hr
            </span>
          </div>
        </div>

        <div className="h-32 w-full pt-1">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={callVolumeTrends60Min} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
              <defs>
                <linearGradient id="incomingGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.35} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                </linearGradient>
                <linearGradient id="activeGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.35} />
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e2638" vertical={false} />
              <XAxis dataKey="time" stroke="#64748b" fontSize={11} tickLine={false} />
              <YAxis stroke="#64748b" fontSize={11} tickLine={false} domain={[0, 'auto']} />
              <RechartsTooltip
                contentStyle={{
                  backgroundColor: "#181d2a",
                  borderColor: "#334155",
                  fontSize: "12px",
                  color: "#f8fafc",
                  borderRadius: "8px",
                  boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.5)"
                }}
              />
              <Area
                type="monotone"
                dataKey="incoming"
                name="Incoming Calls"
                stroke="#10b981"
                strokeWidth={2.5}
                fillOpacity={1}
                fill="url(#incomingGrad)"
                dot={{ r: 3, fill: "#10b981" }}
              />
              <Area
                type="monotone"
                dataKey="active"
                name="Active Sessions"
                stroke="#6366f1"
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#activeGrad)"
                dot={{ r: 3, fill: "#6366f1" }}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 4 Colored Key Metric Cards Row (Matching Screenshot Colors) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Calls in Queue LIVE - ORANGE CARD */}
        <div className="bg-gradient-to-br from-[#c25010] to-[#993b05] border border-amber-500/60 rounded-xl p-4 text-white shadow-lg shadow-amber-950/30 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-1.5 text-xs font-semibold tracking-wide text-amber-100">
              <span>Calls in Queue</span>
              <span className="bg-black/30 text-amber-200 px-1.5 py-0.2 text-[10px] rounded font-bold uppercase">
                LIVE
              </span>
            </div>
            <div className="text-3xl font-black mt-1">
              {queuedCalls.length}
            </div>
            <div className="text-[11px] text-amber-100/80 mt-1 font-medium">
              Pressed 1 & waiting
            </div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-black/20 flex items-center justify-center text-white shrink-0">
            <Hourglass className="w-6 h-6 animate-spin-slow" />
          </div>
        </div>

        {/* Active Calls LIVE - GREEN CARD */}
        <div className="bg-gradient-to-br from-[#128a42] to-[#0a612d] border border-emerald-500/60 rounded-xl p-4 text-white shadow-lg shadow-emerald-950/30 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-1.5 text-xs font-semibold tracking-wide text-emerald-100">
              <span>Active Calls</span>
              <span className="bg-black/30 text-emerald-200 px-1.5 py-0.2 text-[10px] rounded font-bold uppercase">
                LIVE
              </span>
            </div>
            <div className="text-3xl font-black mt-1">
              {activeCalls.length}
            </div>
            <div className="text-[11px] text-emerald-100/80 mt-1 font-medium">
              With agents now
            </div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-black/20 flex items-center justify-center text-white shrink-0">
            <Phone className="w-6 h-6 animate-pulse" />
          </div>
        </div>

        {/* Available Agents - DARK CARD */}
        <div className="bg-[#121620] border border-slate-800/80 rounded-xl p-4 text-white shadow-sm flex items-center justify-between">
          <div>
            <div className="text-xs font-semibold tracking-wide text-slate-400">
              Available Agents
            </div>
            <div className="text-3xl font-black text-sky-400 mt-1">
              {agents.filter((a) => a.status === "AVAILABLE").length}
            </div>
            <div className="text-[11px] text-slate-500 mt-1 font-medium">
              Ready for calls
            </div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-slate-800/80 border border-slate-700/50 flex items-center justify-center text-sky-400 shrink-0">
            <User className="w-6 h-6" />
          </div>
        </div>

        {/* Avg Wait Time - DARK CARD */}
        <div className="bg-[#121620] border border-slate-800/80 rounded-xl p-4 text-white shadow-sm flex items-center justify-between">
          <div>
            <div className="text-xs font-semibold tracking-wide text-slate-400">
              Avg Wait Time
            </div>
            <div className="text-3xl font-black text-slate-100 mt-1 font-mono">
              {stats.avgWaitTimeFormatted}
            </div>
            <div className="text-[11px] text-slate-500 mt-1 font-medium">
              Backend calculation
            </div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-slate-800/80 border border-slate-700/50 flex items-center justify-center text-slate-400 shrink-0">
            <Clock className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Main Panels Grid (3 Columns matching screenshot) */}
      <div className={gridClasses}>
        {/* Panel 1: Queued Calls (Pressed 1) */}
        <div className="bg-[#121620] border border-slate-800/80 rounded-xl p-4 flex flex-col min-h-[280px]">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 mb-3">
            <div className="flex items-center gap-2 font-semibold text-sm text-slate-200">
              <Hourglass className="w-4 h-4 text-amber-400" />
              <span>Queued Calls (Pressed 1)</span>
            </div>
            {queuedCalls.length > 0 && (
              <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 text-xs font-bold border border-amber-500/30">
                {queuedCalls.length} waiting
              </span>
            )}
          </div>

          <div className="flex-1 flex flex-col justify-start">
            {queuedCalls.length > 0 && (
              <div className="mb-3 p-2 bg-[#181d2a] border border-slate-700/60 rounded-lg space-y-2 text-xs">
                <div className="text-[11px] font-semibold text-slate-300 flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-indigo-400">
                    <FolderOutput className="w-3.5 h-3.5" /> Bulk Queue Actions
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">{queuedCalls.length} calls</span>
                </div>
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                  <div className="flex-1 flex items-center gap-1.5">
                    <select
                      value={selectedAgentGroup}
                      onChange={(e) => setSelectedAgentGroup(e.target.value)}
                      className="bg-[#111520] text-slate-200 border border-slate-700 rounded px-2 py-1 text-xs w-full focus:outline-none focus:border-indigo-500"
                    >
                      <option value="Tier 1 Customer Support">Tier 1 Support</option>
                      <option value="Tier 2 Escalations">Tier 2 Escalations</option>
                      <option value="AI Voice Copilots">AI Voice Copilots</option>
                      <option value="VIP Concierge Sales">VIP Concierge Sales</option>
                      <option value="Billing & Claims">Billing & Claims</option>
                    </select>
                    <button
                      onClick={() => {
                        if (onMoveAllQueueCalls) {
                          onMoveAllQueueCalls(selectedAgentGroup);
                          setIsGroupMovedToast(`Moved queue to ${selectedAgentGroup}`);
                          setTimeout(() => setIsGroupMovedToast(null), 3000);
                        }
                      }}
                      className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs px-2.5 py-1 rounded shrink-0 transition-colors"
                    >
                      Move All
                    </button>
                  </div>
                  <button
                    onClick={() => setShowClearQueueModal(true)}
                    className="bg-rose-900/40 hover:bg-rose-900/70 border border-rose-500/40 text-rose-300 font-semibold text-xs px-2.5 py-1 rounded flex items-center justify-center gap-1 transition-colors"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>Clear Queue</span>
                  </button>
                </div>
                {isGroupMovedToast && (
                  <div className="text-[11px] text-emerald-400 font-medium flex items-center gap-1 animate-fadeIn">
                    <Check className="w-3 h-3 text-emerald-400" />
                    <span>{isGroupMovedToast}</span>
                  </div>
                )}
              </div>
            )}

            {queuedCalls.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-8 text-center px-4">
                <div className="w-12 h-12 rounded-full bg-slate-800/80 border border-slate-700/50 flex items-center justify-center text-slate-500 mb-3">
                  <Phone className="w-5 h-5 text-slate-400" />
                </div>
                <div className="text-sm font-semibold text-slate-300">No calls waiting</div>
                <div className="text-xs text-slate-500 mt-1 max-w-xs leading-relaxed">
                  Queue shows only customers who pressed "1" and are actively connected
                </div>
                <button
                  onClick={onOpenSimulator}
                  className="mt-4 text-xs text-indigo-400 hover:text-indigo-300 font-medium underline underline-offset-2"
                >
                  + Trigger incoming call test
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <AnimatePresence mode="popLayout">
                  {queuedCalls.map((q) => {
                    const category = getAICategoryForCall(q);
                    return (
                      <motion.div
                        key={q.id}
                        initial={{ opacity: 0, scale: 0.95, y: -10 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, x: 50, scale: 0.9 }}
                        transition={{ duration: 0.25, ease: "easeOut" }}
                        className="p-3 bg-[#181d2a] border border-amber-500/30 rounded-lg flex items-center justify-between"
                      >
                        <div className="space-y-1">
                          <div className="text-xs font-bold text-white flex items-center gap-2 flex-wrap">
                            <span>{q.phoneNumber}</span>
                            <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded border border-amber-500/30 font-semibold">
                              Pressed 1
                            </span>
                            {/* AI Categorization Badge */}
                            {category === "Urgent" && (
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider flex items-center gap-1 bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse" title="AI Categorized as Urgent based on wait time and caller data">
                                <Flame className="w-3 h-3 text-rose-400" /> Urgent
                              </span>
                            )}
                            {category === "Technical" && (
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider flex items-center gap-1 bg-indigo-500/20 text-indigo-300 border border-indigo-500/40" title="AI Categorized as Technical support inquiry">
                                <Wrench className="w-3 h-3 text-indigo-400" /> Technical
                              </span>
                            )}
                            {category === "Standard" && (
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider flex items-center gap-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40" title="AI Categorized as Standard inquiry">
                                <Tag className="w-3 h-3 text-emerald-400" /> Standard
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-slate-400">
                            Customer: {q.customerName}
                          </div>
                          <div className="text-[10px] text-slate-500 font-mono flex items-center gap-2">
                            <span>Wait: {q.waitTimeSeconds}s</span>
                            {q.campaign && <span className="text-slate-400">• {q.campaign}</span>}
                          </div>
                        </div>
                        <button
                          onClick={() => onRouteQueueCall(q.id)}
                          className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs px-2.5 py-1.5 rounded font-medium transition-colors shrink-0"
                        >
                          Connect
                        </button>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>
            )}
          </div>
        </div>

        {/* Panel 2: Active Calls */}
        <div className="bg-[#121620] border border-slate-800/80 rounded-xl p-4 flex flex-col min-h-[280px]">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 mb-3">
            <div className="flex items-center gap-2.5 font-semibold text-sm text-slate-200">
              <input
                type="checkbox"
                checked={activeCalls.length > 0 && selectedCallIds.length === activeCalls.length}
                onChange={handleToggleSelectAll}
                disabled={activeCalls.length === 0}
                className="w-4 h-4 rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-indigo-500 cursor-pointer disabled:opacity-40"
                title="Select all active calls"
              />
              <Phone className="w-4 h-4 text-emerald-400" />
              <span>Active Calls</span>
            </div>

            <div className="flex items-center gap-2">
              {selectedCallIds.length > 0 && (
                <span className="px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-bold border border-indigo-500/30">
                  {selectedCallIds.length} selected
                </span>
              )}
              {activeCalls.length > 0 && (
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-bold border border-emerald-500/30">
                  {activeCalls.length} active
                </span>
              )}
            </div>
          </div>

          <div className="flex-1 flex flex-col justify-center">
            {activeCalls.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-8 text-center px-4">
                <div className="w-12 h-12 rounded-full bg-slate-800/80 border border-slate-700/50 flex items-center justify-center text-slate-500 mb-3">
                  <Phone className="w-5 h-5 text-slate-400" />
                </div>
                <div className="text-sm font-semibold text-slate-300">No active calls</div>
              </div>
            ) : (
              <div className="space-y-3">
                <AnimatePresence mode="popLayout">
                  {activeCalls.map((call) => {
                    const isSelected = selectedCallIds.includes(call.id);
                    const category = getAICategoryForCall(call);
                    return (
                      <motion.div
                        key={call.id}
                        initial={{ opacity: 0, scale: 0.95, x: -20, filter: "brightness(1.3)" }}
                        animate={{ opacity: 1, scale: 1, x: 0, filter: "brightness(1)" }}
                        exit={{ opacity: 0, scale: 0.9, y: 15 }}
                        transition={{ duration: 0.3, ease: "easeOut" }}
                        className={`p-3.5 bg-[#161b26] border rounded-lg space-y-2.5 transition-all ${
                          isSelected
                            ? "border-indigo-500 ring-1 ring-indigo-500/50 bg-indigo-950/20"
                            : "border-emerald-500/40 hover:border-slate-700"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2.5">
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => handleToggleSelectCall(call.id)}
                              className="w-4 h-4 rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                            />
                            <div>
                              <div className="text-xs font-bold text-white flex items-center gap-1.5 flex-wrap">
                                <span>{call.customerName}</span>
                                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                                {call.status === "muted" && (
                                  <span className="text-[9px] bg-amber-500/20 text-amber-400 px-1 py-0.2 rounded border border-amber-500/30">
                                    MUTED
                                  </span>
                                )}
                                {call.status === "on_hold" && (
                                  <span className="text-[9px] bg-sky-500/20 text-sky-400 px-1 py-0.2 rounded border border-sky-500/30">
                                    ON HOLD
                                  </span>
                                )}
                                {/* AI Category Badge */}
                                {category === "Urgent" && (
                                  <span className="px-1.5 py-0.2 rounded text-[9px] font-bold uppercase tracking-wider flex items-center gap-1 bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse">
                                    <Flame className="w-2.5 h-2.5 text-rose-400" /> Urgent
                                  </span>
                                )}
                                {category === "Technical" && (
                                  <span className="px-1.5 py-0.2 rounded text-[9px] font-bold uppercase tracking-wider flex items-center gap-1 bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">
                                    <Wrench className="w-2.5 h-2.5 text-indigo-400" /> Technical
                                  </span>
                                )}
                                {category === "Standard" && (
                                  <span className="px-1.5 py-0.2 rounded text-[9px] font-bold uppercase tracking-wider flex items-center gap-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                                    <Tag className="w-2.5 h-2.5 text-emerald-400" /> Standard
                                  </span>
                                )}
                              </div>
                              <div className="text-[11px] text-slate-400">{call.phoneNumber}</div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-xs font-mono font-bold text-emerald-400">
                              {Math.floor(call.durationSeconds / 60)}:
                              {(call.durationSeconds % 60).toString().padStart(2, "0")}
                            </div>
                            <div className="text-[10px] text-slate-500">Agent: {call.agentName}</div>
                          </div>
                        </div>

                        {/* Real-Time Sentiment Gauge using D3 */}
                        <div className="pt-2 border-t border-slate-800/60">
                          <div className="flex items-center justify-between mb-1.5">
                            <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider font-mono">
                              Live Sentiment (D3 Gauge)
                            </span>
                            {onUpdateCallSentiment && (
                              <div className="flex items-center gap-1 text-[10px]">
                                <button
                                  onClick={() => onUpdateCallSentiment(call.id, -25)}
                                  className="px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30 hover:bg-rose-500/40 font-mono"
                                  title="Simulate negative tone shift"
                                >
                                  - Tone
                                </button>
                                <button
                                  onClick={() => onUpdateCallSentiment(call.id, 25)}
                                  className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/40 font-mono"
                                  title="Simulate positive tone shift"
                                >
                                  + Tone
                                </button>
                              </div>
                            )}
                          </div>
                          <D3SentimentGauge
                            sentimentScore={call.sentimentScore ?? 50}
                            sentiment={call.sentiment}
                            width={210}
                            height={110}
                          />
                        </div>

                        {/* Dual Waveform Visualization: Customer Audio & AI Agent Pitch Intensity */}
                        <div className="space-y-2 pt-1 border-t border-slate-800/60">
                          {/* Customer Audio Waveform */}
                          <div>
                            <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono mb-1">
                              <span className="flex items-center gap-1 text-emerald-400 font-semibold">
                                <Mic className="w-3 h-3" /> Customer Audio
                              </span>
                              <span className="text-[9px] text-slate-500">{call.audioWaveform[0] || 45} dB</span>
                            </div>
                            <div className="flex items-center gap-1 h-4 bg-slate-900/90 p-1 rounded border border-slate-800">
                              {call.audioWaveform.map((val, idx) => (
                                <div
                                  key={idx}
                                  style={{ height: `${Math.max(15, val)}%` }}
                                  className={`flex-1 rounded-full transition-all duration-300 ${
                                    call.status === "muted"
                                      ? "bg-slate-600"
                                      : call.status === "on_hold"
                                      ? "bg-amber-400"
                                      : "bg-emerald-400"
                                  }`}
                                />
                              ))}
                            </div>
                          </div>

                          {/* AI Agent Voice Pitch Intensity Waveform */}
                          <div>
                            <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono mb-1">
                              <span className="flex items-center gap-1 text-indigo-400 font-semibold">
                                <Bot className="w-3 h-3 text-indigo-400" /> AI Agent Pitch Intensity
                              </span>
                              <span className="text-[9px] text-slate-500">{(call.agentPitchWaveform || [50])[0] || 50} Hz</span>
                            </div>
                            <div className="flex items-center gap-1 h-4 bg-slate-900/90 p-1 rounded border border-slate-800">
                              {(call.agentPitchWaveform || [35, 55, 75, 45, 65, 85, 55, 45, 65, 35]).map((val, idx) => (
                                <div
                                  key={idx}
                                  style={{ height: `${Math.max(15, val)}%` }}
                                  className="flex-1 rounded-full bg-indigo-500/90 transition-all duration-300"
                                />
                              ))}
                            </div>
                          </div>
                        </div>

                        {/* Call Control Buttons */}
                        <div className="flex items-center justify-between pt-1 text-xs">
                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => onMuteCall(call.id)}
                              className={`p-1.5 rounded ${
                                call.status === "muted"
                                  ? "bg-amber-500/20 text-amber-400"
                                  : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                              }`}
                              title="Mute Call"
                            >
                              {call.status === "muted" ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                            </button>
                            <button
                              onClick={() => onHoldCall(call.id)}
                              className={`p-1.5 rounded ${
                                call.status === "on_hold"
                                  ? "bg-amber-500/20 text-amber-400"
                                  : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                              }`}
                              title="Hold Call"
                            >
                              <PhoneForwarded className="w-3.5 h-3.5" />
                            </button>
                          </div>
                          <button
                            onClick={() => onEndCall(call.id)}
                            className="bg-rose-600 hover:bg-rose-500 text-white px-2.5 py-1 rounded text-[11px] font-semibold flex items-center gap-1 transition-colors"
                          >
                            <PhoneOff className="w-3 h-3" />
                            <span>End Call</span>
                          </button>
                        </div>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>
            )}
          </div>
        </div>

        {/* Panel 3: Agent Status */}
        <div className="bg-[#121620] border border-slate-800/80 rounded-xl p-4 flex flex-col">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 mb-3 flex-wrap gap-2">
            <div className="flex items-center gap-2 font-semibold text-sm text-slate-200">
              <User className="w-4 h-4 text-sky-400" />
              <span>Agent Status</span>
              {idleAlertAgents.length > 0 && (
                <div
                  className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/50 text-[10px] font-bold animate-pulse shadow-sm shadow-amber-950/50"
                  title={`${idleAlertAgents.length} agents in AVAILABLE status over 10 minutes without taking a call`}
                >
                  <AlertTriangle className="w-3 h-3 text-amber-400" />
                  <span>{idleAlertAgents.length} Idle &gt;10m</span>
                </div>
              )}
            </div>
            
            <div className="flex items-center gap-2">
              <button
                onClick={handleExportAgentMetricsReport}
                className="bg-slate-800 hover:bg-slate-700 text-sky-300 border border-slate-700 hover:border-sky-500/50 px-2.5 py-1 rounded text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
                title="Download JSON report of today's agent performance metrics"
              >
                <Download className="w-3.5 h-3.5 text-sky-400" />
                <span>Export Report</span>
              </button>

              <span className="text-xs text-slate-500 font-mono bg-slate-900/80 px-2 py-1 rounded border border-slate-800">
                {agents.filter((a) => a.status === "AVAILABLE").length}/{agents.length} Online
              </span>
            </div>
          </div>

          <div className="space-y-3 flex-1 overflow-y-auto">
            {agents.map((agent) => {
              const isTop = agent.isTopPerformer || agent.callsToday >= 100 || agent.csatRating >= 4.9;
              const isIdleAlert = agent.status === "AVAILABLE" && (agent.idleMinutes || 0) >= 10;
              return (
                <div
                  key={agent.id}
                  className={`group relative p-3 bg-[#161b26] border rounded-lg flex items-center justify-between transition-all hover:bg-[#1c2230] cursor-pointer ${
                    isIdleAlert
                      ? "border-amber-500/60 bg-amber-950/10 shadow-md shadow-amber-950/30"
                      : isTop
                      ? "border-amber-500/40 shadow-sm shadow-amber-950/20"
                      : "border-slate-800"
                  }`}
                >
                  <div>
                    <div className="text-xs font-bold text-white flex items-center gap-1.5 flex-wrap">
                      <span>{agent.name}</span>
                      {agent.role === "AI Agent" && (
                        <span className="text-[9px] bg-indigo-500/20 text-indigo-300 px-1 py-0.2 rounded border border-indigo-500/30 font-mono">
                          AI
                        </span>
                      )}
                      {isTop && (
                        <span className="inline-flex items-center gap-1 text-[9px] font-bold bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded-full border border-amber-500/40">
                          <Award className="w-3 h-3 text-amber-400" />
                          <span>Top Performer</span>
                        </span>
                      )}
                      {isIdleAlert && (
                        <span
                          className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/50 text-[10px] font-bold flex items-center gap-1 animate-pulse shadow-sm shadow-amber-950/50"
                          title="Agent available over 10 mins without taking a call"
                        >
                          <Clock className="w-3 h-3 text-amber-400" />
                          <span>Idle {agent.idleMinutes}m Alert</span>
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-2">
                      <span>{agent.callsToday} calls today</span>
                      {agent.avgSentimentScore && (
                        <span className="text-emerald-400 font-mono font-semibold">
                          Score: {agent.avgSentimentScore}%
                        </span>
                      )}
                    </div>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleAgentStatus(agent.id);
                    }}
                    className={`px-2.5 py-1 rounded text-[10px] font-bold tracking-wider transition-all uppercase ${
                      agent.status === "AVAILABLE"
                        ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 hover:bg-emerald-500/30"
                        : agent.status === "BUSY"
                        ? "bg-rose-500/20 text-rose-400 border border-rose-500/40"
                        : "bg-slate-800 text-slate-400 border border-slate-700"
                    }`}
                  >
                    {agent.status}
                  </button>

                  {/* Shift Performance Summary Hover Tooltip */}
                  <div className="absolute right-0 bottom-full mb-2 z-30 w-64 p-3 bg-[#181d2a] border border-indigo-500/40 rounded-xl shadow-2xl shadow-black/90 opacity-0 group-hover:opacity-100 transition-all duration-200 pointer-events-none group-hover:pointer-events-auto text-xs space-y-2.5">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
                      <div className="font-bold text-white flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                        <span>Shift Performance</span>
                      </div>
                      <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-1.5 py-0.5 rounded font-mono border border-indigo-500/30">
                        {agent.role}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px]">
                      <div className="bg-slate-900/90 p-2 rounded-lg border border-slate-800">
                        <div className="text-[10px] text-slate-400 font-medium">Calls Handled Today</div>
                        <div className="text-sm font-bold text-white mt-0.5">{agent.callsToday} calls</div>
                      </div>
                      <div className="bg-slate-900/90 p-2 rounded-lg border border-slate-800">
                        <div className="text-[10px] text-slate-400 font-medium">Avg Satisfaction</div>
                        <div className="text-sm font-bold text-amber-400 mt-0.5 flex items-center gap-1">
                          <span>★ {agent.csatRating.toFixed(1)}</span>
                          <span className="text-[9px] text-slate-500">/ 5.0</span>
                        </div>
                      </div>
                      <div className="bg-slate-900/90 p-2 rounded-lg border border-slate-800">
                        <div className="text-[10px] text-slate-400 font-medium">Avg Handle Time</div>
                        <div className="text-sm font-bold text-sky-400 font-mono mt-0.5">{agent.avgHandleTime}</div>
                      </div>
                      <div className="bg-slate-900/90 p-2 rounded-lg border border-slate-800">
                        <div className="text-[10px] text-slate-400 font-medium">Avg Sentiment</div>
                        <div className="text-sm font-bold text-emerald-400 font-mono mt-0.5">{agent.avgSentimentScore ?? 92}%</div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Bottom Panel: Recent Completed Calls Table */}
      <div className="bg-[#121620] border border-slate-800/80 rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-bold text-white tracking-wide">
              Recent Completed Calls
            </h3>
            <span className="px-2 py-0.5 bg-slate-800 text-slate-300 font-mono text-xs rounded-full font-semibold border border-slate-700">
              {completedCalls.length}
            </span>
          </div>
          <div className="text-xs text-slate-500">
            Real-time telephony sync active
          </div>
        </div>

        {/* Table View matching screenshot */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300 border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-500 font-semibold text-[11px] uppercase tracking-wider">
                <th className="py-2.5 px-3">Time</th>
                <th className="py-2.5 px-3">Phone Number</th>
                <th className="py-2.5 px-3">Customer</th>
                <th className="py-2.5 px-3">Agent</th>
                <th className="py-2.5 px-3">Duration</th>
                <th className="py-2.5 px-3">Wait Time</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
              {completedCalls.map((record) => (
                <tr
                  key={record.id}
                  className="hover:bg-slate-800/40 transition-colors group"
                >
                  <td className="py-3 px-3 font-medium text-slate-300">
                    {record.time}
                  </td>
                  <td className="py-3 px-3 text-slate-400">
                    {record.phoneNumber}
                  </td>
                  <td className="py-3 px-3 font-semibold text-slate-200">
                    {record.customer}
                  </td>
                  <td className="py-3 px-3 text-slate-300 font-medium">
                    {record.agent}
                  </td>
                  <td className="py-3 px-3 text-slate-300">
                    {record.duration}
                  </td>
                  <td className="py-3 px-3 text-slate-400">
                    {record.waitTime}
                  </td>
                  <td className="py-3 px-3">
                    <span className="px-2 py-0.5 rounded text-[10px] font-sans font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                      {record.status}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right font-sans">
                    <button
                      onClick={() => {
                        setSelectedRecord(record);
                        if (onSelectCallRecord) onSelectCallRecord(record);
                      }}
                      className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] px-2.5 py-1 rounded transition-colors border border-slate-700/80 inline-flex items-center gap-1"
                    >
                      <FileText className="w-3 h-3 text-indigo-400" />
                      <span>Details</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail Modal for Selected Call Record */}
      {selectedRecord && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-[#121620] border border-slate-800 rounded-xl w-full max-w-xl p-6 space-y-4 shadow-2xl text-slate-200">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-indigo-400" />
                <h3 className="font-bold text-lg text-white">Call Recording & AI Insights</h3>
              </div>
              <button
                onClick={() => setSelectedRecord(null)}
                className="text-slate-400 hover:text-white text-sm px-2 py-1 bg-slate-800 rounded"
              >
                Close
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs bg-slate-900/80 p-3 rounded-lg border border-slate-800">
              <div>
                <span className="text-slate-500">Customer:</span>{" "}
                <strong className="text-slate-200">{selectedRecord.customer}</strong>
              </div>
              <div>
                <span className="text-slate-500">Agent:</span>{" "}
                <strong className="text-slate-200">{selectedRecord.agent}</strong>
              </div>
              <div>
                <span className="text-slate-500">Duration:</span>{" "}
                <span className="font-mono text-emerald-400 font-semibold">{selectedRecord.duration}</span>
              </div>
              <div>
                <span className="text-slate-500">Wait Time:</span>{" "}
                <span className="font-mono text-amber-400">{selectedRecord.waitTime}</span>
              </div>
            </div>

            {/* AI Summary */}
            <div className="space-y-1">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wide">
                AI Executive Summary
              </div>
              <p className="text-xs text-slate-300 leading-relaxed bg-[#181d2a] p-3 rounded-lg border border-slate-800">
                {selectedRecord.summary || "Call completed cleanly with 100% satisfaction."}
              </p>
            </div>

            {/* Transcript Preview */}
            <div className="space-y-2 max-h-48 overflow-y-auto">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wide">
                Transcript Log
              </div>
              {selectedRecord.transcript?.map((t, idx) => (
                <div key={idx} className="p-2 bg-slate-900/60 rounded border border-slate-800 text-xs">
                  <span className="font-bold text-indigo-400">{t.speaker}:</span>{" "}
                  <span className="text-slate-300">{t.text}</span>
                </div>
              ))}
            </div>

            {/* Simulated Audio Player */}
            <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex items-center justify-between">
              <div className="flex items-center gap-3">
                <button className="w-8 h-8 rounded-full bg-indigo-600 hover:bg-indigo-500 flex items-center justify-center text-white">
                  <Play className="w-4 h-4 ml-0.5" />
                </button>
                <div>
                  <div className="text-xs font-semibold text-white">Audio Recording Playback</div>
                  <div className="text-[10px] text-slate-500 font-mono">24kHz PCM Lossless</div>
                </div>
              </div>
              <div className="text-xs font-mono text-slate-400">{selectedRecord.duration}</div>
            </div>
          </div>
        </div>
      )}

      {/* Floating Action Bar for Bulk Call Operations */}
      {selectedCallIds.length > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-[#161b26] border border-indigo-500/50 shadow-2xl shadow-indigo-950/80 rounded-2xl px-5 py-3.5 flex items-center gap-4 text-white backdrop-blur-md animate-fadeIn transition-all">
          <div className="flex items-center gap-2.5">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-indigo-500"></span>
            </span>
            <div className="text-xs font-bold text-slate-100 font-mono">
              {selectedCallIds.length} Active Call{selectedCallIds.length > 1 ? "s" : ""} Selected
            </div>
          </div>

          <div className="h-5 w-px bg-slate-700/80" />

          <div className="flex items-center gap-2">
            <button
              onClick={handleBulkMuteCalls}
              className="bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 transition-all active:scale-95"
              title="Mute / Unmute all selected calls"
            >
              <VolumeX className="w-3.5 h-3.5" />
              <span>Bulk Mute</span>
            </button>

            <button
              onClick={handleBulkHoldCalls}
              className="bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/40 text-xs px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 transition-all active:scale-95"
              title="Hold / Resume all selected calls"
            >
              <PhoneForwarded className="w-3.5 h-3.5" />
              <span>Bulk Hold</span>
            </button>

            <button
              onClick={handleBulkEndCalls}
              className="bg-rose-600 hover:bg-rose-500 text-white text-xs px-3.5 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition-all shadow-md shadow-rose-950/50 active:scale-95"
              title="End all selected calls immediately"
            >
              <PhoneOff className="w-3.5 h-3.5" />
              <span>Bulk End ({selectedCallIds.length})</span>
            </button>
          </div>

          <div className="h-5 w-px bg-slate-700/80" />

          <button
            onClick={() => setSelectedCallIds([])}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
            title="Deselect All"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}
      {/* Clear Queue Confirmation Modal */}
      {showClearQueueModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#121620] border border-rose-500/50 rounded-2xl p-6 max-w-md w-full space-y-4 shadow-2xl shadow-rose-950/50 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-lg bg-rose-500/20 text-rose-400">
                  <AlertTriangle className="w-5 h-5" />
                </span>
                <div>
                  <h3 className="text-sm font-bold text-white">Clear All Queued Calls?</h3>
                  <div className="text-[11px] text-slate-400">Irreversible telephony action</div>
                </div>
              </div>
              <button
                onClick={() => setShowClearQueueModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Are you sure you want to purge all <strong className="text-white font-mono">{queuedCalls.length} queued calls</strong>?
              Callers waiting in queue will be disconnected immediately and logged.
            </p>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setShowClearQueueModal(false)}
                className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs font-semibold transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onCleanupQueue();
                  setShowClearQueueModal(false);
                }}
                className="px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-rose-950/50 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Confirm Clear Queue</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
