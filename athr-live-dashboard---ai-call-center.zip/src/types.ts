export type NavSection =
  | "dashboard"
  | "command_center"
  | "asterisk_gateway"
  | "campaigns"
  | "phone_lists"
  | "scripts"
  | "ai_agent_scripts"
  | "email_sender"
  | "all_tools"
  | "panel"
  | "call_records"
  | "call_recordings"
  | "analytics"
  | "reports"
  | "billing"
  | "settings"
  | "changelog";

export interface SentEmailRecord {
  messageId: string;
  recipient: string;
  subject: string;
  body: string;
  sentAt: string;
  status: "DELIVERED" | "SENDING" | "FAILED";
  sender: string;
  callIdRef?: string | null;
}

export type LayoutMode = "grid" | "columns" | "focus" | "compact";

export interface ActiveCall {
  id: string;
  phoneNumber: string;
  customerName: string;
  agentName: string;
  startTime: string;
  durationSeconds: number;
  pressedOne: boolean;
  status: "connected" | "on_hold" | "muted" | "transferring";
  sentiment: "Positive" | "Neutral" | "Negative";
  sentimentScore: number;
  queueWaitTime: string;
  campaign: string;
  transcript: {
    speaker: "customer" | "agent" | "system";
    text: string;
    timestamp: string;
  }[];
  audioWaveform: number[];
  agentPitchWaveform?: number[];
  copilotSuggestions?: string[];
  category?: "Urgent" | "Standard" | "Technical";
}

export interface QueuedCall {
  id: string;
  phoneNumber: string;
  customerName: string;
  queueEnteredTime: string;
  waitTimeSeconds: number;
  pressedOne: boolean;
  campaign: string;
  priority: "High" | "Normal" | "VIP";
  category?: "Urgent" | "Standard" | "Technical";
}

export interface AgentStatus {
  id: string;
  name: string;
  role: "AI Agent" | "Human Agent" | "Supervisor";
  status: "AVAILABLE" | "BUSY" | "ON_BREAK" | "OFFLINE";
  callsToday: number;
  avatarUrl?: string;
  avgHandleTime: string;
  csatRating: number;
  currentCallId?: string;
  avgSentimentScore?: number;
  isTopPerformer?: boolean;
  idleMinutes?: number;
}

export interface CompletedCallRecord {
  id: string;
  time: string;
  phoneNumber: string;
  customer: string;
  agent: string;
  duration: string;
  waitTime: string;
  status: "Completed" | "Dropped" | "Voicemail" | "Transferred";
  campaign?: string;
  sentiment?: "Positive" | "Neutral" | "Negative";
  summary?: string;
  recordingUrl?: string;
  transcript?: { speaker: string; text: string; timestamp: string }[];
}

export interface CallCenterStats {
  totalPanelSessions: number;
  activeSessions: number;
  completedSessions: number;
  verifiedSessions: number;
  callsInQueue: number;
  activeCalls: number;
  availableAgents: number;
  avgWaitTimeFormatted: string; // e.g. "0:00" or "0:12"
}

export interface Campaign {
  id: string;
  name: string;
  type: "Inbound" | "Predictive Outbound" | "Power Dialer" | "SMS Followup";
  status: "Active" | "Paused" | "Completed" | "Draft";
  completionPercentage: number;
  totalLeads: number;
  dialedCount: number;
  connectedCount: number;
  convertedCount: number;
  assignedAgentIds: string[];
}

export interface PhoneList {
  id: string;
  name: string;
  totalContacts: number;
  validNumbers: number;
  doNotCallCount: number;
  createdDate: string;
  status: "Ready" | "Processing" | "Archived";
  callerIdAssigned: string;
}

export interface Script {
  id: string;
  title: string;
  type: "AI Agent Prompt" | "Human Script" | "Hybrid Interactive";
  version: string;
  lastUpdated: string;
  systemPrompt: string;
  openingGreeting: string;
  objectionHandlers: { objection: string; response: string }[];
  closingStatement: string;
  assignedCampaign: string;
}
