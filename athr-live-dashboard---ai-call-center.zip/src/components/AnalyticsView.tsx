import React from "react";
import { BarChart3, TrendingUp, Clock, PhoneIncoming, ThumbsUp } from "lucide-react";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid
} from "recharts";

const hourlyCallData = [
  { time: "00:00", calls: 12, resolved: 11 },
  { time: "02:00", calls: 8, resolved: 8 },
  { time: "04:00", calls: 24, resolved: 22 },
  { time: "06:00", calls: 65, resolved: 60 },
  { time: "08:00", calls: 140, resolved: 132 },
  { time: "10:00", calls: 210, resolved: 198 },
  { time: "12:00", calls: 185, resolved: 175 },
  { time: "14:00", calls: 230, resolved: 220 },
  { time: "16:00", calls: 190, resolved: 182 },
  { time: "18:00", calls: 110, resolved: 105 },
  { time: "20:00", calls: 45, resolved: 42 },
];

const waitVsHandleData = [
  { agent: "Daunts Agent.", avgWait: 12, avgHandle: 105 },
  { agent: "trey", avgWait: 18, avgHandle: 130 },
  { agent: "AI Bot Alpha", avgWait: 3, avgHandle: 52 },
  { agent: "Sarah Connors", avgWait: 15, avgHandle: 195 },
];

const sentiment7DayData = [
  { day: "Mon", sentimentScore: 82, positiveCalls: 142 },
  { day: "Tue", sentimentScore: 79, positiveCalls: 138 },
  { day: "Wed", sentimentScore: 88, positiveCalls: 175 },
  { day: "Thu", sentimentScore: 85, positiveCalls: 160 },
  { day: "Fri", sentimentScore: 93, positiveCalls: 210 },
  { day: "Sat", sentimentScore: 91, positiveCalls: 115 },
  { day: "Sun", sentimentScore: 96, positiveCalls: 98 },
];

export const AnalyticsView: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto bg-[#0b0e14] p-6 space-y-6 text-slate-200 font-sans">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-indigo-400" />
            <span>Call Center Analytics & SLA Reports</span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Hourly call volume, average handle times, CSAT score tracking, and SLA benchmarks
          </p>
        </div>
      </div>

      {/* Metric Highlights */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#121620] border border-slate-800 rounded-xl p-4 space-y-1">
          <div className="text-[11px] font-medium text-slate-400 uppercase">CSAT Satisfaction</div>
          <div className="text-2xl font-bold text-emerald-400 flex items-center gap-2">
            <span>98.4%</span>
            <ThumbsUp className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-[10px] text-slate-500">+2.1% from last week</div>
        </div>

        <div className="bg-[#121620] border border-slate-800 rounded-xl p-4 space-y-1">
          <div className="text-[11px] font-medium text-slate-400 uppercase">First Contact Resolution</div>
          <div className="text-2xl font-bold text-indigo-400">92.6%</div>
          <div className="text-[10px] text-slate-500">Benchmark target 90%</div>
        </div>

        <div className="bg-[#121620] border border-slate-800 rounded-xl p-4 space-y-1">
          <div className="text-[11px] font-medium text-slate-400 uppercase">Average Speed to Answer</div>
          <div className="text-2xl font-bold text-amber-400 font-mono">0:08s</div>
          <div className="text-[10px] text-slate-500">IVR Key 1 routing optimized</div>
        </div>

        <div className="bg-[#121620] border border-slate-800 rounded-xl p-4 space-y-1">
          <div className="text-[11px] font-medium text-slate-400 uppercase">Total Inbound Handled</div>
          <div className="text-2xl font-bold text-white font-mono">1,219</div>
          <div className="text-[10px] text-slate-500">24-hour total</div>
        </div>
      </div>

      {/* 7-Day Sentiment Score Trend Line Chart */}
      <div className="bg-[#121620] border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <span>7-Day Average Call Sentiment Score Trend</span>
            </h2>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Gemini AI-scored sentiment average (%) tracked across all completed telephony sessions
            </p>
          </div>
          <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
            Current Avg: 87.4%
          </span>
        </div>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={sentiment7DayData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1f293d" />
              <XAxis dataKey="day" stroke="#64748b" fontSize={11} />
              <YAxis stroke="#64748b" fontSize={11} domain={[60, 100]} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#181d2a",
                  borderColor: "#334155",
                  fontSize: "12px",
                  color: "#f8fafc",
                  borderRadius: "8px",
                }}
                formatter={(value: any) => [`${value}%`, "Avg Sentiment Score"]}
              />
              <Line
                type="monotone"
                dataKey="sentimentScore"
                stroke="#10b981"
                strokeWidth={3}
                dot={{ r: 5, fill: "#10b981", stroke: "#042f2e", strokeWidth: 2 }}
                activeDot={{ r: 8, fill: "#34d399" }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Hourly Call Volume */}
        <div className="bg-[#121620] border border-slate-800 rounded-xl p-5 space-y-4">
          <h2 className="text-xs font-bold text-white uppercase tracking-wider">
            24-Hour Call Volume vs Resolution Rate
          </h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={hourlyCallData}>
                <defs>
                  <linearGradient id="callsGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1f293d" />
                <XAxis dataKey="time" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={10} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#181d2a",
                    borderColor: "#334155",
                    fontSize: "12px",
                    color: "#f8fafc",
                  }}
                />
                <Area type="monotone" dataKey="calls" stroke="#818cf8" fillOpacity={1} fill="url(#callsGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Agent Handle Time Breakdown */}
        <div className="bg-[#121620] border border-slate-800 rounded-xl p-5 space-y-4">
          <h2 className="text-xs font-bold text-white uppercase tracking-wider">
            Average Handle Time (Seconds) by Agent
          </h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={waitVsHandleData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1f293d" />
                <XAxis dataKey="agent" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={10} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#181d2a",
                    borderColor: "#334155",
                    fontSize: "12px",
                    color: "#f8fafc",
                  }}
                />
                <Bar dataKey="avgHandle" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
