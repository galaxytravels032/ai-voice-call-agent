import React, { useState } from "react";
import { Mail, Send, Sparkles, CheckCircle2, RefreshCw, FileText, Clock, User, Inbox, ShieldCheck } from "lucide-react";
import { SentEmailRecord } from "../types";

interface EmailSenderViewProps {
  sentEmails: SentEmailRecord[];
  onSendEmail: (newEmail: SentEmailRecord) => void;
}

export const EmailSenderView: React.FC<EmailSenderViewProps> = ({ sentEmails, onSendEmail }) => {
  const [recipient, setRecipient] = useState("eleanor.vance@acme-corp.com");
  const [customerName, setCustomerName] = useState("Eleanor Vance");
  const [subject, setSubject] = useState("Follow-up: ATHR Subscription Renewal & Account Upgrade");
  const [templateType, setTemplateType] = useState("Post-Call Follow Up");
  const [callSummaryInput, setCallSummaryInput] = useState(
    "Customer called to verify annual tier pricing and discount eligibility. Confirmed 15% enterprise discount applies upon renewal."
  );
  const [emailBody, setEmailBody] = useState(
    `Hi Eleanor,\n\nThank you for taking the time to speak with our ATHR Telephony team today.\n\nAs discussed during our call, we have verified that your account is eligible for our 15% Enterprise Tier discount upon your annual renewal next month.\n\nSummary of Next Steps:\n- Finalize annual license seat count by Friday\n- Issue formal quote via account portal\n\nPlease let us know if you have any questions!\n\nBest regards,\nATHR Telephony AI Dispatcher`
  );

  const [isDraftingAi, setIsDraftingAi] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [lastSentSuccess, setLastSentSuccess] = useState<SentEmailRecord | null>(null);

  // Generate Email using Gemini API
  const handleGenerateAiEmail = async () => {
    setIsDraftingAi(true);
    try {
      const res = await fetch("/api/email/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName,
          customerEmail: recipient,
          callSummary: callSummaryInput,
          actionItems: ["Review discount quote", "Schedule onboarding session"],
          templateType,
        }),
      });
      const data = await res.json();
      if (data.email) {
        setSubject(data.email.subject || subject);
        setEmailBody(data.email.body || emailBody);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsDraftingAi(false);
    }
  };

  // Dispatch Email via SMTP API
  const handleDispatchEmail = async () => {
    if (!recipient || !subject || !emailBody) return;
    setIsSending(true);
    try {
      const res = await fetch("/api/email/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          recipient,
          subject,
          body: emailBody,
          senderName: "ATHR Telephony AI Dispatcher <dispatch@athr-telephony.internal>",
        }),
      });
      const data = await res.json();
      if (data.emailRecord) {
        onSendEmail(data.emailRecord);
        setLastSentSuccess(data.emailRecord);
        setTimeout(() => setLastSentSuccess(null), 5000);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto bg-[#0b0e14] p-6 space-y-6 text-slate-200 font-sans">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Mail className="w-5 h-5 text-purple-400" />
            <span>AI Email Sender & Call Follow-Up Dispatcher</span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Auto-generate post-call recap emails with Gemini AI and dispatch real-time customer notifications
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleGenerateAiEmail}
            disabled={isDraftingAi}
            className="bg-slate-800 hover:bg-slate-700 text-purple-300 font-semibold text-xs px-3.5 py-2 rounded-lg flex items-center gap-1.5 transition-colors border border-purple-500/30"
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>{isDraftingAi ? "Gemini Drafting..." : "Draft with Gemini AI"}</span>
          </button>
          <button
            onClick={handleDispatchEmail}
            disabled={isSending}
            className="bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs px-4 py-2 rounded-lg flex items-center gap-1.5 transition-colors shadow-md shadow-purple-950/40 active:scale-95 disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
            <span>{isSending ? "Dispatching SMTP..." : "Dispatch Email Now"}</span>
          </button>
        </div>
      </div>

      {lastSentSuccess && (
        <div className="p-4 bg-emerald-950/50 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs flex items-center justify-between animate-fadeIn">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <div>
              <span className="font-bold text-white">Email Dispatched Successfully!</span> Delivered to{" "}
              <span className="font-mono text-emerald-200">{lastSentSuccess.recipient}</span> (ID:{" "}
              <span className="font-mono">{lastSentSuccess.messageId}</span>)
            </div>
          </div>
          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
            STATUS: 200 OK
          </span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Email Composer */}
        <div className="lg:col-span-2 bg-[#121620] border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <FileText className="w-4 h-4 text-purple-400" />
              <span>Email Composer & AI Template Assistant</span>
            </h2>
            <div className="flex items-center gap-2">
              <span className="text-[11px] text-slate-400">Template Style:</span>
              <select
                value={templateType}
                onChange={(e) => setTemplateType(e.target.value)}
                className="bg-[#181d2a] border border-slate-800 rounded text-xs px-2 py-1 text-white focus:outline-none"
              >
                <option>Post-Call Follow Up</option>
                <option>Quote & Renewal Confirmation</option>
                <option>Technical Issue Resolution</option>
                <option>Campaign Welcome Notice</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="text-slate-400 block mb-1 font-medium">Customer Name</label>
              <input
                type="text"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full bg-[#181d2a] border border-slate-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-purple-500"
              />
            </div>
            <div>
              <label className="text-slate-400 block mb-1 font-medium">Recipient Email Address</label>
              <input
                type="email"
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                className="w-full bg-[#181d2a] border border-slate-800 rounded-lg p-2.5 font-mono text-white focus:outline-none focus:border-purple-500"
              />
            </div>
          </div>

          <div className="text-xs space-y-1">
            <label className="text-slate-400 block font-medium">Call Summary / Key Findings Context</label>
            <input
              type="text"
              value={callSummaryInput}
              onChange={(e) => setCallSummaryInput(e.target.value)}
              placeholder="e.g. Call regarding tier discount eligibility..."
              className="w-full bg-[#181d2a] border border-slate-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-purple-500"
            />
          </div>

          <div className="text-xs space-y-1">
            <label className="text-slate-400 block font-medium">Subject Line</label>
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full bg-[#181d2a] border border-slate-800 rounded-lg p-2.5 font-semibold text-white focus:outline-none focus:border-purple-500"
            />
          </div>

          <div className="text-xs space-y-1">
            <label className="text-slate-400 block font-medium">Email Message Body</label>
            <textarea
              rows={9}
              value={emailBody}
              onChange={(e) => setEmailBody(e.target.value)}
              className="w-full bg-[#181d2a] border border-slate-800 rounded-lg p-3 font-mono text-slate-200 text-xs leading-relaxed focus:outline-none focus:border-purple-500"
            />
          </div>
        </div>

        {/* Sent Dispatch History Sidebar */}
        <div className="bg-[#121620] border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Inbox className="w-4 h-4 text-emerald-400" />
              <span>Sent Emails Log</span>
            </h2>
            <span className="text-xs font-mono text-slate-400">{sentEmails.length} Sent</span>
          </div>

          {sentEmails.length === 0 ? (
            <div className="py-12 text-center text-slate-500 space-y-2">
              <Mail className="w-8 h-8 mx-auto text-slate-600" />
              <div className="text-xs font-semibold">No emails dispatched yet</div>
              <p className="text-[11px] max-w-xs mx-auto">
                Draft a follow-up email above or click "Dispatch Email Now" to trigger SMTP delivery.
              </p>
            </div>
          ) : (
            <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
              {sentEmails.map((record) => (
                <div
                  key={record.messageId}
                  className="p-3 bg-[#181d2a] border border-slate-800 rounded-xl space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <div className="text-xs font-bold text-white truncate max-w-[170px]">
                      {record.recipient}
                    </div>
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      {record.status}
                    </span>
                  </div>

                  <div className="text-[11px] text-purple-300 font-medium truncate">
                    {record.subject}
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono">
                    <span>{record.sentAt}</span>
                    <span>{record.messageId}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
