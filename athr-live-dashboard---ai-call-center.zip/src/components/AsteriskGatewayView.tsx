import React, { useState, useEffect } from "react";
import {
  Server,
  Activity,
  Cpu,
  Radio,
  Phone,
  PhoneCall,
  PhoneOff,
  Zap,
  RefreshCw,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  ListFilter,
  Layers,
  Terminal,
  ArrowUpRight,
  Sliders,
  Send,
  Mail
} from "lucide-react";

interface AsteriskGatewayViewProps {
  onOpenSimulator: () => void;
  onNavigateToEmailSender?: () => void;
}

interface AriEvent {
  id: string;
  type: string;
  timestamp: string;
  channel: string;
  details: string;
}

export const AsteriskGatewayView: React.FC<AsteriskGatewayViewProps> = ({
  onOpenSimulator,
  onNavigateToEmailSender
}) => {
  const [loading, setLoading] = useState(false);
  const [serverInfo, setServerInfo] = useState<any>(null);
  const [originateExt, setOriginateExt] = useState("PJSIP/101");
  const [originatePhone, setOriginatePhone] = useState("+1 (800) 555-0199");
  const [originating, setOriginating] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  // Live ARI Event Stream
  const [events, setEvents] = useState<AriEvent[]>([
    {
      id: "ari-101",
      type: "StasisStart",
      timestamp: new Date(Date.now() - 120000).toLocaleTimeString(),
      channel: "PJSIP/twilio-trunk-00000042",
      details: "Application 'athr-ai-dispatcher' entered Stasis mode. Dialplan context: from-pstn"
    },
    {
      id: "ari-102",
      type: "ChannelStateChange",
      timestamp: new Date(Date.now() - 90000).toLocaleTimeString(),
      channel: "PJSIP/twilio-trunk-00000042",
      details: "State changed from 'Ringing' to 'Up' (Answered by Gemini AI Agent 01)"
    },
    {
      id: "ari-103",
      type: "BridgeCreated",
      timestamp: new Date(Date.now() - 85000).toLocaleTimeString(),
      channel: "Bridge/athr-ai-bridge-902",
      details: "Created mixing bridge for Gemini 2.0 Flash Voice Stream (Sampling: 16kHz PCM)"
    },
    {
      id: "ari-104",
      type: "ChannelDtmfReceived",
      timestamp: new Date(Date.now() - 40000).toLocaleTimeString(),
      channel: "PJSIP/twilio-trunk-00000042",
      details: "DTMF digit '1' received. Subscribing channel to Real-Time AI Supervisor"
    }
  ]);

  const fetchAsteriskStatus = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/asterisk/status");
      const data = await res.json();
      if (data.success) {
        setServerInfo(data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAsteriskStatus();
    // Simulate real-time ARI event stream
    const interval = setInterval(() => {
      const newTypes = ["ChannelVarset", "ChannelStateChange", "UserEvent", "StasisStart", "ChannelDtmfReceived"];
      const randomType = newTypes[Math.floor(Math.random() * newTypes.length)];
      const randomChan = `PJSIP/ext-${Math.floor(Math.random() * 800 + 100)}-000000${Math.floor(Math.random() * 90 + 10)}`;
      const newEv: AriEvent = {
        id: `ari-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        type: randomType,
        timestamp: new Date().toLocaleTimeString(),
        channel: randomChan,
        details: `Real-time ARI Stasis websocket frame processed. AI Agent audio bridge active.`
      };
      setEvents((prev) => [newEv, ...prev.slice(0, 19)]);
    }, 8000);

    return () => clearInterval(interval);
  }, []);

  const handleOriginateCall = async () => {
    if (!originatePhone) return;
    setOriginating(true);
    setNotice(null);
    try {
      const res = await fetch("/api/asterisk/originate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          endpoint: originateExt,
          callerId: "ATHR AI Asterisk Gateway",
          extension: originatePhone
        })
      });
      const data = await res.json();
      if (data.success) {
        setNotice(`Successfully originated Asterisk channel ${data.channelId}!`);
        // Add ARI event
        setEvents((prev) => [
          {
            id: `ari-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
            type: "OriginateSuccess",
            timestamp: new Date().toLocaleTimeString(),
            channel: data.channelId,
            details: `Originated call to ${originatePhone} via Asterisk ARI endpoint ${originateExt}`
          },
          ...prev
        ]);
      } else {
        setNotice("Failed to originate call on Asterisk gateway.");
      }
    } catch (e) {
      setNotice("Network error calling Asterisk ARI API.");
    } finally {
      setOriginating(false);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto bg-[#0b0e14] p-6 space-y-6 text-slate-200 font-sans">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-4 gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="p-2 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
              <Server className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-bold text-white tracking-tight">
              Asterisk PBX & AI Agent Gateway
            </h1>
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-bold border border-emerald-500/30 flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              PJSIP / ARI 3.0 ONLINE
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real-time Telephony Infrastructure, Stasis WebSocket Bridge, SIP Trunks & Gemini AI Agent extensions.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchAsteriskStatus}
            className="p-2 bg-[#161b26] hover:bg-slate-800 text-slate-300 border border-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
            title="Refresh Asterisk PBX status"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin text-indigo-400" : ""}`} />
            <span>Refresh Telephony Status</span>
          </button>

          <button
            onClick={onOpenSimulator}
            className="bg-emerald-600 hover:bg-emerald-500 text-white px-3.5 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors shadow-lg shadow-emerald-950/40"
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span>Simulate Incoming Caller</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#121620] border border-slate-800/90 rounded-xl p-4 flex items-center gap-3">
          <div className="p-3 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <Radio className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] font-semibold text-slate-400">PJSIP Channels Active</div>
            <div className="text-lg font-mono font-bold text-white">
              {serverInfo?.activePjsipChannels || 12} Streams
            </div>
            <div className="text-[10px] text-emerald-400 font-medium">100% G.711u / PCM16</div>
          </div>
        </div>

        <div className="bg-[#121620] border border-slate-800/90 rounded-xl p-4 flex items-center gap-3">
          <div className="p-3 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] font-semibold text-slate-400">AI Agent Extensions</div>
            <div className="text-lg font-mono font-bold text-white">3 Active Extensions</div>
            <div className="text-[10px] text-indigo-300 font-medium">Gemini 2.0 Stasis Bridge</div>
          </div>
        </div>

        <div className="bg-[#121620] border border-slate-800/90 rounded-xl p-4 flex items-center gap-3">
          <div className="p-3 rounded-lg bg-purple-500/10 text-purple-400 border border-purple-500/20">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] font-semibold text-slate-400">SIP Trunks Reachable</div>
            <div className="text-lg font-mono font-bold text-white">2 Registered</div>
            <div className="text-[10px] text-purple-300 font-medium">Twilio & Bandwidth</div>
          </div>
        </div>

        <div className="bg-[#121620] border border-slate-800/90 rounded-xl p-4 flex items-center gap-3">
          <div className="p-3 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] font-semibold text-slate-400">ARI Socket Latency</div>
            <div className="text-lg font-mono font-bold text-white">18 ms RTT</div>
            <div className="text-[10px] text-amber-300 font-medium">WebSocket Frame Sync</div>
          </div>
        </div>
      </div>

      {/* Main Grid: Left Column = Trunks & Originate, Right Column = Real-time ARI Log */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (Trunks + Originate) */}
        <div className="space-y-6">
          {/* SIP Trunks */}
          <div className="bg-[#121620] border border-slate-800 rounded-xl p-5 space-y-4">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-indigo-400" />
              <span>Registered SIP Trunks (PJSIP)</span>
            </h2>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-[#181d2a] border border-slate-800 rounded-lg flex items-center justify-between">
                <div>
                  <div className="font-bold text-white flex items-center gap-2">
                    <span>Twilio Elastic SIP Trunk</span>
                    <span className="text-[9px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-1.5 py-0.2 rounded font-mono">
                      REACHABLE
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                    sip:us-east.twilio.com:5060 (PJSIP Endpoint)
                  </div>
                </div>
                <div className="text-right font-mono text-[11px] text-slate-300">
                  <div>18ms RTT</div>
                  <div className="text-emerald-400">SIP 200 OK</div>
                </div>
              </div>

              <div className="p-3 bg-[#181d2a] border border-slate-800 rounded-lg flex items-center justify-between">
                <div>
                  <div className="font-bold text-white flex items-center gap-2">
                    <span>Bandwidth Primary SIP</span>
                    <span className="text-[9px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-1.5 py-0.2 rounded font-mono">
                      REACHABLE
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                    sip:voice.bandwidth.com:5060 (PJSIP Endpoint)
                  </div>
                </div>
                <div className="text-right font-mono text-[11px] text-slate-300">
                  <div>24ms RTT</div>
                  <div className="text-emerald-400">SIP 200 OK</div>
                </div>
              </div>
            </div>
          </div>

          {/* Originate Call via ARI */}
          <div className="bg-[#121620] border border-slate-800 rounded-xl p-5 space-y-4">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Zap className="w-4 h-4 text-emerald-400" />
              <span>Asterisk ARI Channel Dispatcher</span>
            </h2>

            {notice && (
              <div className="p-3 bg-emerald-950/40 border border-emerald-500/50 rounded-lg text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>{notice}</span>
              </div>
            )}

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1 font-semibold">
                  Asterisk ARI Endpoint Extension
                </label>
                <input
                  type="text"
                  value={originateExt}
                  onChange={(e) => setOriginateExt(e.target.value)}
                  className="w-full bg-[#181d2a] border border-slate-800 rounded-lg px-3 py-2 text-white font-mono focus:outline-none focus:border-indigo-500"
                  placeholder="e.g. PJSIP/101"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-semibold">
                  Destination Phone Number
                </label>
                <input
                  type="text"
                  value={originatePhone}
                  onChange={(e) => setOriginatePhone(e.target.value)}
                  className="w-full bg-[#181d2a] border border-slate-800 rounded-lg px-3 py-2 text-white font-mono focus:outline-none focus:border-indigo-500"
                  placeholder="+1 (800) 555-0199"
                />
              </div>

              <button
                onClick={handleOriginateCall}
                disabled={originating}
                className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2.5 rounded-lg transition-colors flex items-center justify-center gap-2 shadow-md shadow-indigo-950/50 disabled:opacity-50"
              >
                {originating ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Originating ARI Channel...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Originate Call via Asterisk ARI</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Link to Real-time Email Sender */}
          <div className="bg-[#121620] border border-slate-800 rounded-xl p-4 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2.5">
              <Mail className="w-4 h-4 text-sky-400" />
              <div>
                <div className="font-bold text-white">Real-Time Email Sender</div>
                <div className="text-[11px] text-slate-400">Post-channel SMTP dispatch logs</div>
              </div>
            </div>
            {onNavigateToEmailSender && (
              <button
                onClick={onNavigateToEmailSender}
                className="text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1"
              >
                <span>View Sender</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Right Column (Live ARI Event Terminal & Connected AI Agents) */}
        <div className="lg:col-span-2 space-y-6">
          {/* Active AI Agent Extensions */}
          <div className="bg-[#121620] border border-slate-800 rounded-xl p-5 space-y-4">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <span>Asterisk AI Agent Extensions (Gemini Voice Bridge)</span>
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              <div className="p-3.5 bg-[#181d2a] border border-emerald-500/40 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white font-mono">PJSIP/ai-agent-01</span>
                  <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30 text-[10px]">
                    BRIDGED
                  </span>
                </div>
                <div className="text-slate-300 font-semibold">Gemini-Voice-Core-1</div>
                <div className="text-[11px] text-slate-400 font-mono truncate">
                  Chan: PJSIP/ext-101-00000021
                </div>
              </div>

              <div className="p-3.5 bg-[#181d2a] border border-slate-800 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white font-mono">PJSIP/ai-agent-02</span>
                  <span className="px-1.5 py-0.2 rounded bg-slate-800 text-slate-400 font-bold border border-slate-700 text-[10px]">
                    IDLE
                  </span>
                </div>
                <div className="text-slate-300 font-semibold">Gemini-Voice-Core-2</div>
                <div className="text-[11px] text-slate-500 font-mono">
                  Ready for Stasis dispatch
                </div>
              </div>

              <div className="p-3.5 bg-[#181d2a] border border-emerald-500/40 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white font-mono">PJSIP/ai-agent-03</span>
                  <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30 text-[10px]">
                    BRIDGED
                  </span>
                </div>
                <div className="text-slate-300 font-semibold">Gemini-Voice-Copilot</div>
                <div className="text-[11px] text-slate-400 font-mono truncate">
                  Chan: PJSIP/ext-104-00000028
                </div>
              </div>
            </div>
          </div>

          {/* Real-time ARI Stasis Event Log */}
          <div className="bg-[#121620] border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <Terminal className="w-4 h-4 text-emerald-400" />
                <span>Asterisk ARI WebSocket Event Log</span>
              </h2>
              <span className="text-xs text-slate-400 font-mono">
                {events.length} Events Logged
              </span>
            </div>

            <div className="bg-[#0a0d13] border border-slate-800 rounded-lg p-3 font-mono text-xs max-h-[380px] overflow-y-auto space-y-2">
              {events.map((ev) => (
                <div
                  key={ev.id}
                  className="p-2 bg-[#121722] border border-slate-800/80 rounded flex flex-col sm:flex-row sm:items-center justify-between gap-2 transition-all hover:border-slate-700"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-1.5 py-0.2 rounded border border-indigo-500/30 font-bold">
                        {ev.type}
                      </span>
                      <span className="text-slate-200 font-bold text-[11px]">{ev.channel}</span>
                    </div>
                    <div className="text-slate-400 text-[11px]">{ev.details}</div>
                  </div>
                  <div className="text-[10px] text-slate-500 whitespace-nowrap self-end sm:self-center">
                    {ev.timestamp}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
